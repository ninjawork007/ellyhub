<?php
function get_category()
{
    return array();
}
