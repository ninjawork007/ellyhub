<?php



namespace App\Http\Controllers\admin;



use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use Illuminate\Foundation\Auth\AuthenticatesUsers;

use Illuminate\Support\Facades\Auth;

use DB;

use Hash;

use Illuminate\Support\Facades\File;

use Illuminate\Support\Facades\Storage;

class OrderController extends Controller{

    use AuthenticatesUsers;

    public function __construct() {

            // $this->middleware('auth');

            // $this->middleware(function ($request, $next) {

            //     if (!Auth::user()) {

            //        return redirect()->route('admin_logout'); 

            //     }

            //     return $next($request);

            // });

    }

	//show admin page

	public function orders(){

	   return view('admin.orders.list');

	 }

	 

    public function ajax_get_orders(Request $request){

        $input = array('search'=>@$_GET['search_'],'order'=>@$_GET['order'][0]['column'],'start'=>@$_GET['start'],'length'=>@$_GET['length'],'draw'=>@$_GET['draw'],'start_date'=>@$_GET['start_date'],'end_date'=>@$_GET['end_date']);

        $search = "";

        $where = "";

        if ($input['search']){

            $search.= "AND (order_id LIKE '%".$input['search']."%')";

        }

        if ($input['start_date']!==''){

            $search.= "AND (created_at >='".$input['start_date']." 00:00:00')";

        }

        if ($input['end_date']!==''){

            $search.= "AND (created_at <='".$input['end_date']." 23:59:59')";

        }

        if ($input['start']=='') {

            $input['start']=0;

        }



        if ($input['length']=='') {

            $input['length']=10;

        }

        

        $totalrows = count(DB::select(DB::raw("SELECT * FROM orders WHERE order_id!='' $search $where GROUP BY order_id")));

        $data  = DB::select(DB::raw("SELECT * FROM orders WHERE order_id!='' $search $where GROUP BY order_id ORDER BY id DESC limit ".$input['start'].",".$input['length'].""));



        $final = [];

        $i=0;

        foreach($data as $row){

        	$delivery='';

        	$delivery.='<select class="form-control delivery_type"  name="delivery_type" ><option> Select Delivery Type</option>';

        	if ($row->delivery_by=='self') {

        	$delivery.='<option value="self" data-id="'.$row->id.'" selected> Self Delivery</option>';

        	}else{

        	$delivery.='<option value="self" data-id="'.$row->id.'"> Self Delivery</option>';

        	}



        	if ($row->delivery_by=='deliforce') {

        		$delivery.='<option value="deliforce" data-id="'.$row->id.'" selected> Deliforce </option>';

        	}else{

        		$delivery.='<option value="deliforce" data-id="'.$row->id.'"> Deliforce </option>';

        	}

        	$delivery.='</select>';



        	// payment status

            $payment_status='';

            if ($row->payment_status=='paid') { $payment_status_paid='selected';}else{$payment_status_paid='';}

            if ($row->payment_status=='pending') { $payment_status_pending='selected';}else{$payment_status_pending='';}

            $payment_status.='<select id="'.$row->order_id.'" data-key="payment_status" class="payment_status"><option value="">Select</option><option value="pending" '.$payment_status_pending.'>Pending</option><option value="paid" '.$payment_status_paid.'>paid</option></select>';



            // delivery status



            $delivery_status='';

            if ($row->delivery_status=='pending') { $delivery_status_pending='selected';}else{$delivery_status_pending='';}

            if ($row->delivery_status=='dispatch') { $delivery_status_dispatch='selected';}else{$delivery_status_dispatch='';}

            if ($row->delivery_status=='delivered') { $delivery_status_delivered='selected';}else{$delivery_status_delivered='';}

            $delivery_status.='<select id="'.$row->order_id.'" data-key="delivery_status" class="delivery_status"><option value="pending" '.$delivery_status_pending.'>Pending</option><option value="dispatch" '.$delivery_status_dispatch.'>Dispatch</option><option value="delivered" '.$delivery_status_delivered.'>Delivered</option></select>';

            $final[] = array(

                            "DT_RowId" => $row->order_id,

                            '<a href="'.url('order_detail',[base64_encode($row->order_id)]).'" target="_blank">'.$row->order_id.'</a>',

                            'Name: '.$row->name.'<br> Email: '.$row->email.'<br> Phone: '.$row->phone,

                            '₹'.$row->order_total,

                            '₹'.$row->after_discount_paid_by_customer,

							$delivery,

                            $row->payment_method,

                            // $row->payment_status,

                            $payment_status,

                            $delivery_status,

                            

                            date('M d, Y',strtotime($row->created_at)),

                            '<div class="btn-group" role="group" aria-label="Basic example">

                            <a target="_blank" href="'.url('order_detail',[base64_encode($row->order_id)]).'" class="btn btn-outline-primary btn-sm"> <i class="fa fa-eye"></i> </a>&nbsp;

							<br><a href="javascript:;" class="delete_row btn btn-outline-danger btn-sm" table="orders" id="'.$row->order_id.'"><i class="fa fa-trash"></i></a>

                            </div>'

                    );

            $i++;

        }



        $json_data = array(

                        "draw"=> intval($input['draw']),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 

                        "recordsTotal"    => intval(count($final) ),  // total number of records

                        "recordsFiltered" => intval($totalrows), // total number of records after searching, if there is no searching then totalFiltered = totalData

                        "data"            => $final   // total data array

                    );

        echo json_encode($json_data);

    }

	

	

	 public function update_delivery_type(Request $request){

		$id = $request->id;

		$order  = DB::table('orders')->Where('id',$id)->first();

		

		 if($request->value == 'self' ){

               DB::table('orders')->where('id',$request->id)->update(['delivery_by'=>$request->value]);

			   //  status updated 

		          echo 1;

				   exit;

		 }

		  

		 

		 if($request->value == 'deliforce' ){

				 if($order->delivery_status == 'deliforce' ){

					// echo "Already Exists";

					 echo 2;

					  exit;

				  } else {

					  

					 $address =  $order->street_address.','.$order->city.','.$order->zip.','.$order->country;

					 $conuntry_code = '91';

					 $number = $order->email;

					  if (substr($number, 0, strlen($conuntry_code)) == $conuntry_code) {

						$number = substr($number, strlen($conuntry_code));

					  } 

					 $phone = ltrim($number, '0');

					 $message = '{

								  "name": "'.$order->name.'",

								  "email": "'.$order->phone.'",

								  "date": "'.date('Y-m-d H:i:s').'",

								  "lastName": "",

								  "endDate": "'.date('Y-m-d H:i:s').'",

								  "FlatNo": "", 

								  "address":  "'.$address.'",

								  "phone":   "+91 '.$phone.'",

								  "isPickup": true,

								  "manual": true,

								  "businessType": 1,

								  "orderId":  "'.$order->name.'",

								  "timezone": "Asia/Calcutta",

								  "driverId": "",

								  "teamId": "",

								  "customerNotes": "customer notes",

								  "description": "'.$order->product_name.'",

								  "latitude": "",

								  "longitude": "",

								  "distance": 0,

								  "merchantId": "",

								  "driverTips": "0",

								  "templateName": "",

								  "templateId": "",

								  "jobAmount": "",

								  "driverType": 1,

								  "transportType": [

									1

								  ],

								  "pricingOrEarningRules": [

									"",

									""

								  ],

								  "images": [

									"https://bazarhat99.com/public/'.$order->image.'"

								  ],

								  "templateData": [

									{

									  "fieldName": "",

									  "fieldValue": "",

									  "dataType": "",

									  "order": 0

									}

								  ]

								}';

							$curl2 = curl_init();

							curl_setopt_array($curl2, array(

							CURLOPT_URL => "https://api.deliforce.io/task",

							CURLOPT_RETURNTRANSFER => true,

							CURLOPT_ENCODING => '',

							CURLOPT_MAXREDIRS => 10,

							CURLOPT_TIMEOUT => 0,

							CURLOPT_FOLLOWLOCATION => true,

							CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,

							CURLOPT_CUSTOMREQUEST => 'POST',

							CURLOPT_POSTFIELDS => $message,

							 CURLOPT_HTTPHEADER => array(

								'accept: */*',

								'APIKEY:  mjFbHmxU42p5HbFbFbcqxkADEybZAknTuYJ61TeNLx6obFbFbiEVKUXNw0jM142vs6CzbFbFbwcFcFc',

								'Content-Type: application/json'

							),

							)); 

							$response = curl_exec($curl2);

							curl_close($curl2);

					  if($response){

						  DB::table('orders')->where('id',$request->id)->update(['delivery_by'=>$request->value]);

						   // echo "assign Success ";

						   echo 3;

						   exit;

					  } else{

						   // echo "error while assign status";

						   echo 4;

						    exit;

		  }  }  }

		  

	 }



	 public function delete_order(Request $request){

	 	DB::table($request->table)->where('order_id',$request->id)->delete();

	 	echo true;

	 }

	 

}

