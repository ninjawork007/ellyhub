@extends('layouts.admin')
@section('content')

<style>
img.image_ {
    width: 100px;
    height: 100px;
    border: 1px solid;
    padding: 10px;
    margin: 8px;
    cursor: pointer;
}
</style>
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="row">
                @if(!Auth::user()->isactive)
                <div class="col-md-12 alert alert-primary" role="alert"">
                  
                  <p class="font-weight-bold">Your account is under verification. Please upload your all details.</p>
                  
                </div>
                @endif
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  @if(!Auth::user()->isactive)
                   <p class="text-center">Note:- Please update details correctly. admin will verify your account by checking your details.</p>
                   @endif
                  <form class="form-sample" method="post" action="{{route('update_vendor_information')}}" data-parsley-validate="" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
					  <div class="col-md-12 text-center profile-pic">
                        @if(@$user_info->profile_photo)
                        <img src="{{@url('public/'.$user_info->profile_photo)}}" class="image_">
                        @else
                        <img src="{{url('public/no-image.png')}}" class="image_">
                        @endif
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" id="title" name="name" value="{{Auth::user()->name}}">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                            <input type="email" class="form-control" required="" readonly="" value="{{Auth::user()->email}}">
                            <small>To change email contact to admin.</small>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Mobile</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" id="title" name="mobile" value="{{Auth::user()->mobile}}">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Complete Address</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" name="address" value="{{@$user_info->complete_address}}">
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Profile</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" name="profile">
                          </div>
                        </div>
                      </div>
                      </div>
                       <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">PAN Card</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" name="pancard">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6 ">
                        
						 @if(@$user_info->pan_card)
                        <img src="{{@url('public/'.$user_info->pan_card)}}" class="image_">
                        @else
                        <img src="{{url('public/no-image.png')}}" class="image_">
                        @endif
						
                      </div>
                      </div>
                       <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Adhar Card</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" name="adharcard">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
						@if(@$user_info->adhar_card)
                        <img src="{{@url('public/'.$user_info->adhar_card)}}" class="image_">
                        @else
                        <img src="{{url('public/no-image.png')}}" class="image_">
                        @endif
                      </div>
                      </div>
                       <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">GST Registration</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" name="gst">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        
						@if(@$user_info->gst_registration)
                        <img src="{{@url('public/'.$user_info->gst_registration)}}" class="image_">
                        @else
                        <img src="{{url('public/no-image.png')}}" class="image_">
                        @endif
                      </div>
                      </div>
                       <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Firm Registration</label>
                          <div class="col-sm-9">
                            <input type="file" class="form-control" name="firm_registration">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
						@if(@$user_info->firm_registration)
                        <img src="{{@url('public/'.$user_info->firm_registration)}}" class="image_">
                        @else
                        <img src="{{url('public/no-image.png')}}" class="image_">
                        @endif
                      </div>
                    </div>
                    <div class="row col-md-12">
                      <input type="submit" class="btn btn-outline-primary btn-fw pull-right" value="Submit">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                  @if(!Auth::user()->isactive)
                   <p class="text-center">Note:- Please update details correctly. admin will verify your account by checking your details.</p>
                   @endif
                  <form class="form-sample" method="post" action="{{route('update_bank_information')}}" data-parsley-validate="">
                    @csrf
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Bank Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" name="bank_name" value="{{@$bank->bank_name}}">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Account Number</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" name="account_number" value="{{@$bank->account_number}}">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Bank IFSC</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" name="ifsc" value="{{@$bank->ifsc}}">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Account Holder Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" required="" name="accountant_name" value="{{@$bank->accountant_name}}">
                          </div>
                        </div>
                      </div>
                    </div>
                      
                    <div class="row col-md-12">
                      <input type="submit" class="btn btn-outline-primary btn-fw pull-right" value="Submit">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
@endsection