@extends('layouts.admin')

@section('content')

<style type="text/css">

  td select.form-control {

    width: 100px;

}

</style>

<div class="main-panel">

        <div class="content-wrapper">

          <h4 class="card-title">Orders</h4>

          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="col-md-3">
                <label>search</label>
                <input type="text" id="search" class="form-control" placeholder="Search by orderid">
              </div>
              <div class="col-md-3">
                <label>From Date</label>
                <input type="date" id="start_date" class="form-control">
              </div>
              <div class="col-md-3">
                <label>To Date</label>
                <input type="date" id="end_date" class="form-control">
              </div>
              <div class="col-md-3 mt-4">
                <label></label>
                <button class="btn btn-primary search" type="button">Search</button>
              </div>
            </div>
            <div class="col-lg-12 grid-margin stretch-card">



              <div class="card">

                @include('alerts')

                <div class="error"></div>

                <div class="card-body">

                  <div class="table-responsive">
                    <table class="table table-hover" id="myTable" >
                      <thead>

                        <tr>

                          <th data-orderable="false">Order Id</th>

                          <th data-orderable="false">Customer</th>

                          <th data-orderable="false">Order Total</th>

                          <th data-orderable="false">Total Paid</th>

                          <th data-orderable="false">Delivery Type</th>

                          <th data-orderable="false">Payment Method</th>

                          <th data-orderable="false">Payment Status</th>
                          <th data-orderable="false">Delivery Status</th>
                          <th data-orderable="false">DOC</th>
                          

                          <th data-orderable="false">Action</th>

                        </tr>

                      </thead>

                      <tbody>

                      </tbody>

                    </table>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

        

      </div> 

 

 

   

<script>

    $(document).ready(function() {


        var table = $("#myTable").DataTable({
            searching:false,
            language: {"processing": "Please wait..."},

            dom: "frtip",

            serverSide: true,

            processing: true,

            stateSave: true,

            ajax: {

                url: "{{route('ajax_get_orders')}}", // json datasource

                type: "get", // method  , by default get

                cache: false,

                "data": function(data) {

                    data.search_ = $('#search').val();
                    data.start_date = $('#start_date').val();
                    data.end_date = $('#end_date').val();
                },

                error: function(data) { // error handling

                    $(".table-grid-error").html("");

                    $("#table-grid").append('<tbody class="table-grid-error"><tr><th colspan="6">No data found!</th></tr></tbody>');

                    $("#table-grid_processing").css("display", "none");

                },

                complete: function(data) {

                    

                }

            },

        });



        // search

        $('#key-search').on('keyup', function() {

            table.search(this.value).draw();

        });

        // account status

        $('.search').on('click', function() {

            table.draw();

        });

    });



$('body').on('change','.status',function(){
 
  id = $(this).attr('id');

  value = $(this).val();

  $.ajax({

    url:"{{route('update_product_status')}}",

    data:{id:id,value:value},

    cache:false,

    success:function(response){

      $('.error').html('<div class="alert alert-info alert-dismissible fade show" role="alert">Status update successfully.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');

    }

  });

});


$('body').on('change','.delivery_type',function(){
 
  var id =  $(this).find(':selected').data('id');

  var value = $(this).val();
 
  $.ajax({

    url:"{{route('update_delivery_type')}}",

    data:{id:id,value:value},

    cache:false,

    success:function(response){
		 
      $('.error').html('<div class="alert alert-info alert-dismissible fade show" role="alert">Status update successfully.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');

    }

  });

});


$('body').on('click','.delete_row',function(){

  id = $(this).attr('id');

  table = $(this).attr('table');

  swal({

        title: "Do you want to delete this order?",

        icon: "warning",

        buttons: true,

        dangerMode: true,

      })

      .then((willDelete) => {

        if (willDelete) {

          $.ajax({

            url:"{{route('delete_order')}}",

            data:{id:id,table:table},

            cache:false,

            success:function(response){

              $('.error').html('<div class="alert alert-success alert-dismissible fade show" role="alert">Product deleted successfully.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');

              $('#'+id+'').fadeOut(1200).css({'background-color':'#f2dede'});

            }

          });

        } 

      });

});
// $('body').on('change','.order_status',function(){
//   id = $(this).attr('id');
//   value = $(this).val();
//   table_key = $(this).attr('data-key');
//  change_status(id,value,table_key);
// });
$('body').on('change','.payment_status',function(){
  id = $(this).attr('id');
  value = $(this).val();
  table_key = $(this).attr('data-key');
 change_status(id,value,table_key);
});
$('body').on('change','.delivery_status',function(){
  id = $(this).attr('id');
  value = $(this).val();
  table_key = $(this).attr('data-key');
 change_status(id,value,table_key);
});
function change_status(orderid,value,table_key) {
   $.ajax({
    url:"{{route('update_order_parameter_admin')}}",
    data:{orderid:orderid,value:value,table_key:table_key},
    cache:false,
    success:function(response){
      $('.error').html('<div class="alert alert-info alert-dismissible fade show" role="alert">Status update successfully.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
    }
  });
}

</script>

@endsection