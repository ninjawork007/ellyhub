@extends('layouts.admin')
@section('content')
<div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="row">
                               
					<div class="card-body">
						<div class="col-md-12 alert alert-primary" role="alert">
					  
							<p class="font-weight-bold">comming soon!!!</p>
					  
						</div>
                  	</div>				

                
              </div>
            </div>
          </div>
          
      </div>
</div>
@endsection