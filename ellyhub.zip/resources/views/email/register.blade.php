<!DOCTYPE html>
<html>
<head>
	<title>{{$setting[0]->site_title}}</title>
</head>
<body>
{!! $data['html'] !!}
</body>
</html>