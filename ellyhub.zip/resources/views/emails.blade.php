<!DOCTYPE html>
<html>
<head>
	<title>emails</title>
</head>
<body>
Hi <strong>{{ $name }}</strong>,
<p>{{ $body }}</p>
</body>
</html>