<?php $__env->startSection('content'); ?>

  <nav class="amrcart-breadcrumb">
    <a href="https://bazarhat99.com">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
    </span> Wallet
</nav>
 <div class="wallet">
       <div  class="content-area">
<main id="main" class="site-main">
    <section class="section--wallet">

            <div class="container">

                <h2 class="page__title">Balance :- ₹<?php echo e(Auth::user()->balance); ?></h2>

                <div class="wishlist__content">

                    <div class="wishlist__product">

                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
</div>
<script type="text/javascript">
</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/wallet.blade.php ENDPATH**/ ?>