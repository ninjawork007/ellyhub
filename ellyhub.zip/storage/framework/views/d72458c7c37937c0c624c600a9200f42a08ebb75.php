<?php $__env->startSection('bodyclass'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="container">
    <div class="row">
        <div id="secondary" class="col-sm-3 shop-sidebar" role="complementary">
            <div id="techmarket_products_filter-3" class="widget widget_techmarket_products_filter">
                <span class="gamma widget-title">Filters</span>
                <!-- .amrcart widget_layered_nav -->
                <div class="widget amrcart widget_layered_nav maxlist-more" id="amrcart_layered_nav-3">
                    <span class="gamma widget-title">All Categories</span>
                    <ul>
                    <?php if(count($top_cat)): ?>
                    <?php $__currentLoopData = $top_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="form-check">
                            <label id="<?php echo e($key->id); ?>" value="<?php echo e($key->id); ?>" onclick="make_filter('category','<?php echo e($key->id); ?>')">
                            <input name="categories" class="categories" type="checkbox" id="<?php echo e($key->id); ?>" value="<?php echo e($key->id); ?>" <?php if(@in_array($key->id,$cat_array)){echo 'checked';}?>> <?php echo e($key->name); ?><span>(0)</span></label>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </ul>
                    <p class="maxlist-more"><a href="#">+ Show more</a></p>
                </div>
                <!-- .amrcart widget_layered_nav -->
                <div class="widget amrcart widget_layered_nav maxlist-more" id="amrcart_layered_nav-2">
                    <span class="gamma widget-title">Brands</span>
                    <ul>
                        <?php if(count($top_brand)): ?>
                        <?php $__currentLoopData = $top_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="form-check">
                                <label id="<?php echo e($key->id); ?>" value="<?php echo e($key->id); ?>" onclick="make_filter('brand','<?php echo e($key->id); ?>')">
                                <input name="brand" type="checkbox" id="<?php echo e($key->id); ?>" class="brand" value="<?php echo e($key->id); ?>" <?php if(@in_array($key->id,$brand_array)){echo 'checked';}?>> <?php echo e($key->title); ?><span>(0)</span></label>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                    <p class="maxlist-more"><a href="#">+ Show more</a></p>
                </div>
                
            </div>
            
        </div>
<div id="primary" class="col-sm-7 content-area">
        <div class="shop-control-bar" style="display: none;">
            <div class="handheld-sidebar-toggle">
                <button type="button" class="btn sidebar-toggler">
                    <i class="fa fa-sliders"></i>
                    <span>Filters</span>
                </button>
            </div>
            <!-- .handheld-sidebar-toggle -->
            <h1 class="amrcart-products-header__title page-title"><?php echo e($product->count()); ?> <span>Product Found</span>
            </h1>
            <ul role="tablist" class="shop-view-switcher nav nav-tabs">
                <li class="nav-item">
                    <a href="#grid" title="Grid View" data-toggle="tab" class="nav-link active">
                        <i class="icon amr-grid-small"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#grid-extended" title="Grid Extended View" data-toggle="tab" class="nav-link ">
                        <i class="icon amr-grid"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#list-view-large" title="List View Large" data-toggle="tab" class="nav-link ">
                        <i class="icon amr-listing-large"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#list-view" title="List View" data-toggle="tab" class="nav-link ">
                        <i class="icon amr-listing"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#list-view-small" title="List View Small" data-toggle="tab" class="nav-link ">
                        <i class="icon amr-listing-small"></i>
                    </a>
                </li>
            </ul>
            <!-- .shop-view-switcher -->
            <form class="form-amr-wc-ppp" method="POST">
                <select class="amr-wc-wppp-select c-select" onchange="this.form.submit()" name="ppp">
                    <option value="20">Show 20</option>
                    <option value="40">Show 40</option>
                    <option value="-1">Show All</option>
                </select>
                <input type="hidden" value="5" name="shop_columns">
                <input type="hidden" value="15" name="shop_per_page">
                <input type="hidden" value="right-sidebar" name="shop_layout">
            </form>
            <!-- .form-amr-wc-ppp -->
            <form method="get" class="amrcart-ordering">
                <select class="orderby" name="orderby">
                    <option value="popularity">Sort by popularity</option>
                    <option value="rating">Sort by average rating</option>
                    <option selected="selected" value="date">Sort by newness</option>
                    <option value="price">Sort by price: low to high</option>
                    <option value="price-desc">Sort by price: high to low</option>
                </select>
                <input type="hidden" value="5" name="shop_columns">
                <input type="hidden" value="15" name="shop_per_page">
                <input type="hidden" value="right-sidebar" name="shop_layout">
            </form>
            <!-- .amrcart-ordering -->
            <nav class="amr-advanced-pagination">
                <form class="form-adv-pagination" method="post">
                    <input type="number" value="1" class="form-control" step="1" max="5" min="1" size="2"
                        id="goto-page">
                </form> of 5<a href="#" class="next page-numbers">→</a>
            </nav>
            <!-- .amr-advanced-pagination -->
        </div>
        <div class="category-products-list columns-4">
            <?php if($product->count()): ?>
            <div class="products">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product">
                    <div class="amr-add-to-wishlist">
                        <a onclick="add_wishlist(<?php echo e($key->id); ?>,'wishlist')" href="JavaScript:void(0);" rel="nofollow"
                            class="add_to_wishlist"> Add to Wishlist</a>
                    </div>
                    <a class="amr-LoopProduct-link" href="<?php echo e(route('product_details',[$key->id])); ?>">
                        <?php if($key->discount_type): ?>
                        <span class="onsale">
                            <?php if($key->discount): ?>
                            <span class="amr-Price-amount amount">
                                <?php if($key->discount_type=='flat'): ?>
                                <?php echo e('Rs '. $key->discount); ?> off
                                <?php else: ?>
                                <?php echo e($key->discount); ?>% off
                                <?php endif; ?>
                            </span>
                            <?php endif; ?>
                        </span>
                        <?php endif; ?>
                        <div class="amr-product-img">
                            <img src="<?php echo e(url('public/'.$key->image)); ?>" alt="<?php echo e($key->name); ?>">
                        </div>
                        <div class="pro-info">
                        <h2 class="amr-loop-product-title"><?php echo e($key->name); ?></h2>
                        <span class="price">
                            <ins>
                                <span class="amount"> ₹<?php echo e($key->sale_price); ?></span>
                            </ins>
                            <?php if($key->sale_price != $key->mrp_price): ?>
                            <del>
                                <span class="amount">₹<?php echo e($key->mrp_price); ?></span>
                            </del>
                            <?php endif; ?>
                            <span class="amount"></span>
                        </span>
                        <!-- <div><?php echo e($key->vendor_name); ?></div> -->
                        </div>

                    </a>
                    <div class="hover-area">
                        <a class="button add_to_cart_button" href="<?php echo e(route('product_details',[$key->id])); ?>"
                            rel="nofollow">View Product</a>
                        <?php if(@$key->shipping_time == 'yes'): ?>
                        <p class="amr-shipping-estimate">
                            <i class="icon amr-order-tracking"></i> Delivery - <?php echo e(@$key->estimate_time); ?>

                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <div class="products row justify-content-center">
                <img src="<?php echo e(url('public/not-found.jpg')); ?>">
            </div>
            <?php endif; ?>

            <div class="text-center pagination-col">
                       <?php echo e($product->appends(request()->query())->links()); ?>

            </div>

        </div>
</div>


</div>
</section>
<script type="text/javascript">
    function make_filter(type,id) {
        cat_array = '';
        brand_array = '';

        var brand_array = jQuery.map($('.brand:checkbox:checked'), function (n, i) {
            return n.value;
        }).join(',');
        var cat_array = jQuery.map($('.categories:checkbox:checked'), function (n, i) {
            return n.value;
        }).join(',');
        baseurl = "<?php echo e(url('filter?')); ?>";
        if (cat_array!='') {
            cat = '&category='+cat_array;
        }else{
            cat = '';
        }

        if (brand_array!='') {
            brand = 'brand='+brand_array;
        }else{
            brand = '';
        }

        window.location.href=baseurl+brand+cat;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amrkartroot/public_html/multivendor/resources/views/category_details.blade.php ENDPATH**/ ?>