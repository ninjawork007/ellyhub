<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Dashboard || Bazarhat99</title>
  <!-- plugins:css --> 
  <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(url('public/assets/admin/images/favicon.png')); ?>" />
  <link rel="shortcut icon" href="<?php echo e(url('public/assets/parsley/parsley.css')); ?>" />
  <script src="<?php echo e(url('public/assets/admin/vendors/js/vendor.bundle.base.js')); ?>"></script>
   <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/css/layout-light/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/vendors/ti-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/css/layout-light/custom.css')); ?>">
</head>
<body class="sidebar-dark">
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo mr-5" href="<?php echo e(url('admin/dashboard')); ?>"><img src="<?php echo e(url('public/assets/logo/logo.png')); ?>" class="mr-2" alt="logo"/></a>
        <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('admin/dashboard')); ?>"><img src="<?php echo e(url('public/assets/logo/logo.png')); ?>" alt="logo"/></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="ti-layout-grid2"></span>
        </button>
        
        <ul class="navbar-nav navbar-nav-right">
         
          
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link" href="#" data-toggle="dropdown" id="profileDropdown">
              <img src="<?php echo e(url('public/assets/admin/images/faces/face28.jpg')); ?>" alt="profile"/>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
              <?php if(Auth::user()->user_type=='vendor'): ?>
              <a class="dropdown-item" href="<?php echo e(route('my_profile')); ?>">
                <i class="fa fa-user text-primary"></i>
                <p class="">Profile</p>
              </a>
              <?php endif; ?>
              <a class="dropdown-item" href="<?php echo e(route('admin_logout')); ?>">
                <i class="fa fa-sign-out text-primary"></i>
                <p class="">Logout</p>
              </a>
            </div>
          </li>
          
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="ti-layout-grid2"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
     
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'admin_dashboard',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin_dashboard')); ?>">
              <i class="fa fa-tachometer menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
		   <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'brand_list',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('brand_list')); ?>">
              <i class="fa fa-image menu-icon"></i>
              <span class="menu-title">Brand List</span>
            </a>
        </li>
        <?php if(Auth::user()->user_type=='superadmin'): ?>
        <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'banner_list',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('banner_list')); ?>">
              <i class="fa fa-image menu-icon"></i>
              <span class="menu-title">Banner List</span>
            </a>
          </li>
        <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'delivery',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('delivery')); ?>">
              <i class="fa fa-users menu-icon"></i>
              <span class="menu-title">Delivery</span>
            </a>
        </li>
        <?php if(Auth::user()->admin_type=='admin'): ?>
          <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'admin_staff',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin_staff')); ?>">
              <i class="fa fa-users menu-icon"></i>
              <span class="menu-title">Staff</span>
            </a>
          </li>
          <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'vendor_list','vendor_payments']))? 'active':''); ?>">
            <a class="nav-link" data-toggle="collapse" href="#Vendor" aria-expanded="false" aria-controls="Vendor">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Vendor</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="Vendor">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('vendor_list')); ?>">Vendor</a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('vendor_payments')); ?>">Vendor Payments</a></li>
              </ul>
            </div>
          </li>
		  <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'customer',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('customer')); ?>">
              <i class="fa fa-users menu-icon"></i>
              <span class="menu-title">Customer</span>
            </a>
          </li>
        <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'coupens',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('coupens')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Coupons</span>
            </a>
          </li>
        
      <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'comming_soon',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('comming_soon')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Accounts</span>
            </a>
      </li>
      
      <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'comming_soon',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('comming_soon')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Ticket</span>
            </a>
          </li> 
      <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'blogs',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('blogs')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Blogs</span>
            </a>
          </li> 
          <?php endif; ?>
         <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'category_list','add_category','edit_category']))? 'active':''); ?>">
            <a class="nav-link" data-toggle="collapse" href="#Category" aria-expanded="false" aria-controls="Category">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Category</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="Category">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('category_list')); ?>">Category</a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('sub_category_list')); ?>">Sub Category</a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('child_category_list')); ?>">Child Category</a></li>
              </ul>
            </div>
          </li>
        <?php endif; ?>
        <?php if(Auth::user()->isactive=='1'): ?>
          <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[]))? 'active':''); ?>">
            <a class="nav-link" data-toggle="collapse" href="#Products" aria-expanded="false" aria-controls="Products">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Products</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="Products">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='products')?'active':''); ?>" href="<?php echo e(route('products')); ?>">All Products</a></li>

                <li class="nav-item"> <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='product_stock')?'active':''); ?>" href="<?php echo e(route('product_stock')); ?>">Product Stock Status</a></li>

                <li class="nav-item "> <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='product_stock')?'active':''); ?>" href="<?php echo e(route('product_bulk_upload')); ?>">Products Bulk Upload</a></li>

                <li class="nav-item"> <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='unapproved_products')?'active':''); ?>" href="<?php echo e(route('unapproved_products')); ?>">Disapproved Products</a></li>

                <li class="nav-item"> <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='deleted_products')?'active':''); ?>" href="<?php echo e(route('deleted_products')); ?>">Deleted products</a></li>
<!-- 
                <li class="nav-item"> <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='deleted_products')?'active':''); ?>" href="<?php echo e(route('product_bundle')); ?>">  Product Bundle</a></li> -->
              </ul>
            </div>
          </li>
          <?php endif; ?>
		  
		  <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),['product_stock_report','vendor_payment_report','payment_history']))? 'active':''); ?>">
            <a class="nav-link" data-toggle="collapse" href="#reports" aria-expanded="false" aria-controls="reports">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Reports</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="reports">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='product_stock_report')?'active':''); ?>" href="<?php echo e(route('product_stock_report')); ?>">Stock Report</a>
                </li>
                <?php if(Auth::user()->user_type!=='vendor'): ?>
                <!-- <li class="nav-item"> 
                  <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='vendor_payments_report')?'active':''); ?>" href="<?php echo e(route('vendor_payments_report')); ?>">Vendor Payment Report</a>
                </li> -->
                <?php endif; ?>
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='payment_history')?'active':''); ?>" href="<?php echo e(route('payment_history')); ?>">Payment History</a>
                </li>
                <li class="nav-item"> 
                  <a class="nav-link <?php echo e((Route::getCurrentRoute()->getName()=='sale_report')?'active':''); ?>" href="<?php echo e(route('sale_report')); ?>">Sale Report</a>
                </li>
              </ul>
            </div>
          </li>
		  <?php if(Auth::user()->user_type=='vendor'): ?>
		 <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'my_sale',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('my_sale')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Order History</span>
            </a>
      </li>
      <?php endif; ?>
      <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),['sale']))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('sale')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Sale</span>
            </a>
      </li>
		   <?php if(Auth::user()->user_type=='superadmin'): ?>
       <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'admin_orders',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin_orders')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Orders History</span>
            </a>
      </li>
       <?php endif; ?>
       <?php if(Auth::user()->user_type=='superadmin'): ?>
		  <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'pages',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('pages')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Pages</span>
            </a>
          </li>
          <?php endif; ?>
      <?php if(Auth::user()->user_type=='superadmin'): ?>
		  <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'send_mail',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('send_mail')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Send mail</span>
            </a>
      </li>
		  <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'customer_wallet',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('customer_wallet')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Customer wallet</span>
            </a>
      </li>
      <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'pin_codes',]))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('pin_codes')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Pin Codes</span>
            </a>
      </li>
		   <?php endif; ?>
       <?php if(Auth::user()->user_type=='vendor'): ?>
       <li class="nav-item <?php echo e((in_array(Route::getCurrentRoute()->getName(),[ 'notifications']))? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(route('notifications')); ?>">
              <i class="fa fa-list-alt menu-icon"></i>
              <span class="menu-title">Notifications</span>
              <i class="fa fa-bell"></i>
              <span class="no">0</span>
            </a>
      </li>
       <?php endif; ?>
        </ul>
      </nav>
      <!-- partial -->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- main-panel ends -->
    </div>
 
  </div>
  <!-- container-scroller -->
  
 <script src="<?php echo e(url('public/assets/admin/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
 <script src="<?php echo e(url('public/assets/admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
  <!-- plugins:js -->
  
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="<?php echo e(url('public/assets/admin/vendors/chart.js/Chart.min.js')); ?>"></script>

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(url('public/assets/admin/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/template.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/settings.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(url('public/assets/admin/js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/parsley/parsley.js')); ?>"></script>
  <script type="text/javascript" src="//unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  
  
  <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#show_img').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

  <script type="text/javascript">
  
    function delete_row(id,table) {
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover data!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            url:'<?php echo e(route("delete_row")); ?>',
            data:{id:id,table:table},
            cache:false,
            success:function(res){
              if (res) {
                $('#'+id+'').fadeOut(1200).css({'background-color':'#f2dede'});
              }
            }
          });
        } 
      });
    }
  </script>
    <script type="text/javascript">
	/* De Active Row*/
    function active_row(id,table,status) {
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover data!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
         /*  $.ajax({
            url:'<?php echo e(route("delete_row")); ?>',
            data:{id:id,table:table},
            cache:false,
            success:function(res){
              if (res) {
                $('#'+id+'').fadeOut(1200).css({'background-color':'#f2dede'});
              }
            }
          }); */
        } 
      });
    }
  </script>
    <script type="text/javascript">
	/* Active Row*/
    function deactive_row(id,table,status) {
      swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover data!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
         /*  $.ajax({
            url:'<?php echo e(route("delete_row")); ?>',
            data:{id:id,table:table},
            cache:false,
            success:function(res){
              if (res) {
                $('#'+id+'').fadeOut(1200).css({'background-color':'#f2dede'});
              }
            }
          }); */
        } 
      });
    }
get_notification()
    function get_notification(){
      id = "<?php echo e(Auth::user()->id); ?>";
          $.ajax({
            url:'<?php echo e(route("get_notification_count")); ?>',
            data:{id:id},
            cache:false,
            success:function(res){
              $('.no').html(res);
            }
          }); 
    }
  </script>
</body>
</html><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/layouts/admin.blade.php ENDPATH**/ ?>