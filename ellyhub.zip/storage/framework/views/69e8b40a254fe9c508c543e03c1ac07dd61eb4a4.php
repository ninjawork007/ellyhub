<?php $__env->startSection('content'); ?>

   
        <div class="ps-breadcrumb">
            <div class="container">
                <ul class="ps-breadcrumb__list">
                    <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="javascript:void(0);"><?php echo e($brands->title); ?></a></li>
                </ul>
            </div>
        </div>
        <section class="section-shop shop-categories--default">
            <div class="container">
                <div class="row">
                    
                    <div class="col-12 col-lg-12">
                        <div class="category__top">
                            <div class="category__header">
                                <h3 class="category__name">
								<img src="<?php echo e(url('public/')); ?>/<?php echo e($brands->banner); ?>" class="top_cat_img">
								<?php echo e($brands->title); ?>

								</h3>
                              
                            </div>
                        </div>
                        <div class="result__header">
                            <h4 class="title"> <?php echo e(count($product)); ?> <span>Product Found</span></h4>
                        </div>

                        <div class="result__header mobile">
                            <h4 class="title">   <?php echo e(count($product)); ?><span>Product Found</span></h4>
                        </div>
						
                        <div class="result__content mt-4">
                            	<div class="categories__products">
                                <div class="row m-0 get_brand_product">
 
                                        
									
									
							   </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
       
 
<script type="text/javascript">
     $.ajax({
            url:"<?php echo e(route('get_brand_product')); ?>",
		    data:{id:<?php echo $brands->id; ?>,_token: '<?php echo e(csrf_token()); ?>'},
			method:"post",  
           cache:false,
          success:function(response){
             console.log(response);
              $('.get_brand_product').html(response);
          }
     });
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/brand_details.blade.php ENDPATH**/ ?>