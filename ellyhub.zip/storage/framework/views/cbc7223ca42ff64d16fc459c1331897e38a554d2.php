<?php $__env->startSection('content'); ?>
 
   <main class="no-main">
        <div class="ps-breadcrumb">
            <div class="container">
                <ul class="ps-breadcrumb__list">
                    <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
					
					<?php if($product->category_id): ?>  
                    <li class="active"><a href="javascript:void(0);"> </a><?php echo e(App\Http\Controllers\CommonController::getCategoryName($product->category_id)); ?></li>
					<?php endif; ?>
					
					<?php if($product->sub_category_id): ?>
                    <li class="active"><a href="javascript:void(0);"> </a><?php echo e(App\Http\Controllers\CommonController::getSubCategoryName($product->sub_category_id)); ?></li>
					<?php endif; ?>
					
					<?php if($product->child_category_id): ?>
                    <li class="active"><a href="javascript:void(0);"> </a><?php echo e(App\Http\Controllers\CommonController::getChildCategoryName($product->child_category_id)); ?></li>
					<?php endif; ?>
                    <!-- <li><a href="javascript:void(0);"><?php echo e($product->name); ?></a></li> -->
                </ul>
            </div>
        </div>
        <section class="section--product-type section-product--default">
            <div class="container">
                <div class="product__header">
                    <h3 class="product__name"><?php echo e($product->name); ?></h3>
                    <div class="row">
                        <div class="col-12 col-lg-7 product__code">
                            <select class="rating-stars">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5" selected="selected">5</option>
                            </select><span class="product__review">4 Customer Review</span><span class="product__id">SKU: <span>#<?php echo e($product->sku); ?></span></span>
                        </div>
                    </div>
                </div>
                <div class="product__detail">
                    <div class="row">
                        <div class="col-12 col-lg-9">
                            <div class="ps-product--detail">
                                <div class="row">
                                    <div class="col-12 col-lg-6">
                                        <div class="ps-product__variants">
                                            <div class="ps-product__gallery">
                                             <?php if(count($product_gallery)): ?>
											     <?php $__currentLoopData = $product_gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											          <div class="ps-gallery__item"><img src="<?php echo e(url('public/')); ?>/<?php echo e($key->images); ?>" /></div>
											      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											 <?php endif; ?>
                                            </div>
                                            <div class="ps-product__thumbnail">
                                                <div class="ps-product__zoom"><img id="ps-product-zoom" src="<?php echo e(url('public/')); ?>/<?php echo e($product->image); ?>" alt="alt" />
                                                    <ul class="ps-gallery--poster" id="ps-lightgallery-videos" data-video-url="#">
                                                        <li data-html="#video-play"><span></span><i class="fa fa-play-circle"></i></li>
                                                    </ul>
                                                </div>
                                                <div style="display:none;" id="video-play">
													<iframe width="420" height="345" src="https://www.youtube.com/embed/tgbNymZ7vqY"></iframe>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <div class="ps-product__sale"><span class="price-sale">₹<?php echo e($product->sale_price); ?>/-<?php echo e($product->unit); ?></span>
                                            <?php if($product->discount): ?>
                                            <span class="price">₹<?php echo e($product->mrp_price); ?></span>
                                            <?php endif; ?>
                                            <?php if($product->discount): ?> <?php if($product->discount_type=='flat'): ?>
                                            <span class="ps-product__off">RS <?php echo e($product->discount); ?> Off</span>
                                            <?php else: ?>
                                            <span class="ps-product__off"><?php echo e($product->discount); ?>% Off</span>
                                            <?php endif; ?>
                                            
                                            <?php endif; ?>
                                        </div>
										
										<?php
                                        $stock=0;
                                        if(count($product_size)){
                                            foreach ($product_size as $key) {
                                                $stock+=$key->quantity;
                                            }
                                        }
                                        ?>
                                        <div class="ps-product__avai alert__<?php echo e(($product->stock)?'success':'error'); ?>">Availability: <span><?php echo e(($product->stock)? $product->stock.'in stock': 'Out of Stock'); ?> </span></div>
                                         
										<div class="ps-product__info">
                                            <!--ul class="ps-list--rectangle">
                                                <li> <span><i class="icon-square"></i></span>Type: Organic</li>
                                                <li> <span><i class="icon-square"></i></span>MFG: Jun 4.2020</li>
                                                <li> <span><i class="icon-square"></i></span>LIFE: 30 days</li>
                                            </ul-->
											<?php echo $product->short_description; ?>

                                        </div>
                                        <?php if($product->stock): ?>
                                        <?php if(count($product_size)): ?>
                                        <div class="ps-product__shopping">
                                        	

                                        		<select class="form-control" id="product_size" name="product_size">
                                        			<option value="">Select Size</option>
                                        			<?php $__currentLoopData = $product_size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        			<option value="<?php echo e($key->name); ?>" data-value="<?php echo e($key->price); ?>"><?php echo e($key->name); ?></option>
                                        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        		</select>
                                        	
                                        </div>
                                        <?php endif; ?>
                                        <?php if(count($product_colors)): ?>
                                        <div class="ps-product__shopping color">
                                        	<ul id="menu">
                                        	<?php $__currentLoopData = $product_colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        	<li class="color-list" data-value="<?php echo e($key->color_code); ?>">
                                        		<div class="color-col" style="background-color: <?php echo e($key->color_code); ?>"></div>
                                        	</li>
                                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        	</ul>  
                                        	<div class="clearfix"></div>
                                        </div>
                                        <?php endif; ?>
                                        <div class="ps-product__shopping">
                                            <div class="ps-product__quantity">
                                                <label>Quantity: </label>
                                                <div class="def-number-input number-input safari_only">
                                                    <button class="minus ps-button detail" onclick="this.parentNode.querySelector('input[type=number]').stepDown()" data-id="<?php echo e($product->id); ?>"><i class="icon-minus"></i></button>
                                                    <?php if(count($cart)): ?>
                                                    <input class="quantity" min="0" max="<?php echo e($product->stock); ?>" name="quantity" value="<?php echo e($cart[0]->product_quantity); ?>" type="number" id="detail_input<?php echo e($product->id); ?>" readonly="" />
                                                    <?php else: ?>
                                                    <input class="quantity" min="0" max="<?php echo e($product->stock); ?>" name="quantity" value="0" type="number" id="detail_input<?php echo e($product->id); ?>" readonly="" />
                                                    <?php endif; ?>
                                                    <button class="plus ps-button detail" onclick="this.parentNode.querySelector('input[type=number]').stepUp()" data-id="<?php echo e($product->id); ?>"><i class="icon-plus"></i></button>
                                                </div>
                                            </div>
											<!--a class="ps-product__addcart ps-button" data-toggle="modal" data-target="#popupAddToCart"><i class="icon-cart"></i>Add to cart</a-->
											<a class="ps-product__icon" href="javascript:;" onclick="add_wishlist('<?php echo e($product->id); ?>','wishlist')"><i class="fa fa-heart <?php echo e(($wishlist)?'red':''); ?>"></i></a>
											<!-- <a class="ps-product__icon"><i class="icon-repeat"></i></a> -->
                                        </div>
                                        <?php endif; ?>
                                        <div class="ps-product__category">
                                            <ul>
											     <?php if($product->brand): ?>
													<li>Brand: <a href="<?php echo e(url('brand/')); ?>/<?php echo e($product->brand); ?>"  class='text-success'><?php echo e(App\Http\Controllers\CommonController::getBrandName($product->brand)); ?></a></li>
                                                 <?php endif; ?>
												 
											     <?php if($product->vendor_id): ?>
													<li>Vendor: <a href="<?php echo e(url('vendor/')); ?>/<?php echo e($product->vendor_id); ?>" class='text-success'> <?php echo e(App\Http\Controllers\CommonController::getVendorName($product->vendor_id)); ?></a></li>
												 <?php endif; ?>
											    
													<li>Categories:   
													 <?php if($product->category_id): ?>  
														<a href="<?php echo e(url('category/')); ?>/<?php echo e($product->category_id); ?>" class='text-success'> 
															<?php echo e(App\Http\Controllers\CommonController::getCategoryName($product->category_id)); ?> 
														</a>
													<?php endif; ?>
													
													 <?php if($product->sub_category_id): ?>
													 	<a href="<?php echo e(url('sub-category/')); ?>/<?php echo e($product->sub_category_id); ?>" class='text-success'> 
															<?php echo e(App\Http\Controllers\CommonController::getSubCategoryName($product->sub_category_id)); ?> 
													   </a>
													 <?php endif; ?>
													
													 <?php if($product->child_category_id): ?>
														<a href="<?php echo e(url('child-category/')); ?>/<?php echo e($product->vendor_id); ?>" class='text-success'> 
															<?php echo e(App\Http\Controllers\CommonController::getChildCategoryName($product->child_category_id)); ?> 
													    </a>
													 <?php endif; ?>
													 </li>
					
												 <?php if($product->tags): ?>
													<li>Tags: <a href="#" class='text-primary tags'> <?php echo e($product->tags); ?></a></li>
												<?php endif; ?>
 
										  </ul>
                                        </div>
                                        <div class="ps-product__footer"><a class="ps-product__shop" href="#"><i class="icon-store"></i><span>Store</span></a><a class="ps-product__addcart ps-button" data-toggle="modal" data-target="#popupAddToCart"><i class="icon-cart"></i>Add to cart</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-3">
                            <div class="ps-product--extention">
							<?php if($product->shipping_time): ?>
                                <div class="extention__block">
                                    <div class="extention__item">
                                        <div class="extention__icon"><i class="icon-truck"></i></div>
                                        <div class="extention__content"> <b class="text-black"> Shipping : </b>  <?php echo e($product->estimate_time); ?></div>
                                    </div> 
                                </div>
								<?php endif; ?>
								
                                <!--div class="extention__block">
                                    <div class="extention__item">
                                        <div class="extention__icon"><i class="icon-leaf"></i></div>
                                        <div class="extention__content">Guranteed <b class="text-black">100% Organic </b>from natural farmas </div>
                                    </div>
                                </div-->
                                <div class="extention__block">
                                    <div class="extention__item border-none">
                                        <div class="extention__icon"><i class="icon-repeat-one2"></i></div>
                                        <div class="extention__content"> <b class="text-black"><?php echo $product->policy; ?></div>
                                    </div>
                                </div>
                                <!--div class="extention__block extention__contact">
                                    <p> <span class="text-black">Hotline Order: </span>Free 7:00-21:30</p>
                                    <h4 class="extention__phone">970978-6290</h4>
                                    <h4 class="extention__phone">970343-8888</h4>
                                </div-->
                                <p class="extention__footer">Become a Vendor? <a href="<?php echo e(route('vendor_register')); ?>">Register now</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="container">
                 
                <div class="product__content">
                    <ul class="nav nav-pills" role="tablist" id="productTabDetail">
                        <li class="nav-item"><a class="nav-link active" id="description-tab" data-toggle="tab" href="#description-content" role="tab" aria-controls="description-content" aria-selected="true">Description</a></li>
                        <li class="nav-item"><a class="nav-link" id="reviews-tab" data-toggle="tab" href="#reviews-content" role="tab" aria-controls="reviews-content" aria-selected="false">Reviews(4)</a></li>
                        <li class="nav-item"><a class="nav-link" id="policy-tab" data-toggle="tab" href="#policy-content" role="tab" aria-controls="policy-content" aria-selected="false">Buy/Return Policy</a></li>
                        <li class="nav-item"><a class="nav-link" id="vendor-tab" data-toggle="tab" href="#vendor-content" role="tab" aria-controls="vendor-content" aria-selected="false">Vendor Info</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="description-content" role="tabpanel" aria-labelledby="description-tab">
                       
					   <?php echo $product->description; ?>

					  
					   </div>
                          <div class="tab-pane fade" id="reviews-content" role="tabpanel" aria-labelledby="reviews-tab">
                            <div class="ps-product--reviews">
                                <div class="row">
                                    <div class="col-12 col-lg-5">
                                        <div class="review__box">
                                            <div class="product__rate">4.5</div>
                                            <select class="rating-stars">
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4" selected="selected">4</option>
                                                <option value="5">5</option>
                                            </select>
                                            <p>Avg. Star Rating: <b class="text-black">(4 reviews)</b></p>
                                            <div class="review__progress">
                                                <div class="progress-item"><span class="star">5 Stars</span>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 80%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div><span class="percent">80%</span>
                                                </div>
                                                <div class="progress-item"><span class="star">4 Stars</span>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 20%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div><span class="percent">20%</span>
                                                </div>
                                                <div class="progress-item"><span class="star">3 Stars</span>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 0%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div><span class="percent">0%</span>
                                                </div>
                                                <div class="progress-item"><span class="star">2 Stars</span>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 0%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div><span class="percent">0%</span>
                                                </div>
                                                <div class="progress-item"><span class="star">1 Stars</span>
                                                    <div class="progress">
                                                        <div class="progress-bar bg-warning" role="progressbar" style="width: 0%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div><span class="percent">0%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-7">
                                        <div class="review__title">Add A Review</div>
                                        <p class="mb-0">Your email will not be published. Required fields are marked <span class="text-danger">*</span></p>
                                        <form>
                                            <div class="form-row">
                                                <div class="col-12 form-group--block">
                                                    <div class="input__rating">
                                                        <label>Your rating: <span>*</span></label>
                                                        <select class="rating-stars">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4" selected="selected">4</option>
                                                            <option value="5">5</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-12 form-group--block">
                                                    <label>Review: <span>*</span></label>
                                                    <textarea class="form-control"></textarea>
                                                </div>
                                                <div class="col-12 col-lg-6 form-group--block">
                                                    <label>Name: <span>*</span></label>
                                                    <input class="form-control" type="text" required>
                                                </div>
                                                <div class="col-12 col-lg-6 form-group--block">
                                                    <label>Email:</label>
                                                    <input class="form-control" type="email">
                                                </div>
                                                <div class="col-12 form-group--block">
                                                    <button class="btn ps-button ps-btn-submit">Submit Review</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="ps--comments">
                                    <h5 class="comment__title">4 Comments</h5>
                                    <ul class="comment__list">
                                        <li class="comment__item">
                                            <div class="item__avatar"><img src="img/blogs/comment_avatar1.png" alt="alt" /></div>
                                            <div class="item__content">
                                                <div class="item__name">Elyn Y.</div>
                                                <div class="item__date">- June 14, 2020</div>
                                                <div class="item__check"> <i class="icon-checkmark-circle"></i>Verified Purchase</div>
                                                <div class="item__rate">
                                                    <select class="rating-stars">
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4" selected="selected">4</option>
                                                        <option value="5">5</option>
                                                    </select>
                                                </div>
                                                <p class="item__des">Farmart is great. Farmart is the most valuable business resource we have EVER purchased. I have gotten at least 50 times the value from Farmart. I just can't get enough of Farmart. I want to get a T-Shirt with Farmart on it so I can show it off to everyone.</p>
                                            </div>
                                        </li>
                                        <li class="comment__item">
                                            <div class="item__avatar"><img src="img/blogs/comment_avatar2.png" alt="alt" /></div>
                                            <div class="item__content">
                                                <div class="item__name">Rick E.</div>
                                                <div class="item__date">- June 14, 2020</div>
                                                <div class="item__check"> <i class="icon-checkmark-circle"></i>Verified Purchase</div>
                                                <div class="item__rate">
                                                    <select class="rating-stars">
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4" selected="selected">4</option>
                                                        <option value="5">5</option>
                                                    </select>
                                                </div>
                                                <p class="item__des">Farmart is great. Farmart is the most valuable business resource we have EVER purchased. I have gotten at least 50 times the value from Farmart. I just can't get enough of Farmart. I want to get a T-Shirt with Farmart on it so I can show it off to everyone.</p>
                                            </div>
                                        </li>
                                        <li class="comment__item">
                                            <div class="item__avatar"><img src="img/blogs/comment_no_avatar.png" alt="alt" /></div>
                                            <div class="item__content">
                                                <div class="item__name">Timmi Y.</div>
                                                <div class="item__date">- June 13, 2020</div>
                                                <div class="item__check"> <i class="icon-checkmark-circle"></i>Verified Purchase</div>
                                                <div class="item__rate">
                                                    <select class="rating-stars">
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5" selected="selected">5</option>
                                                    </select>
                                                </div>
                                                <p class="item__des">Farmart is great. Farmart is the most valuable business resource we have EVER purchased. I have gotten at least 50 times the value from Farmart. I just can't get enough of Farmart. I want to get a T-Shirt with Farmart on it so I can show it off to everyone.</p>
                                            </div>
                                        </li>
                                        <li class="comment__item">
                                            <div class="item__avatar"><img src="img/blogs/comment_no_avatar.png" alt="alt" /></div>
                                            <div class="item__content">
                                                <div class="item__name">Jack F.</div>
                                                <div class="item__date">- June 05, 2020</div>
                                                <div class="item__check"> <i class="icon-checkmark-circle"></i>Verified Purchase</div>
                                                <div class="item__rate">
                                                    <select class="rating-stars">
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5" selected="selected">5</option>
                                                    </select>
                                                </div>
                                                <p class="item__des">Farmart is great. Farmart is the most valuable business resource we have EVER purchased. I have gotten at least 50 times the value from Farmart. I just can't get enough of Farmart. I want to get a T-Shirt with Farmart on it so I can show it off to everyone.</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="policy-content" role="tabpanel" aria-labelledby="policy-tab">
						
						<?php echo $product->policy; ?>

						</div>
                        <div class="tab-pane fade" id="vendor-content" role="tabpanel" aria-labelledby="vendor-tab">
						
						   <?php if($product->vendor_id): ?>
							<li>Vendor: <a href="<?php echo e(url('vendor/')); ?>/<?php echo e($product->vendor_id); ?>" class='text-success'> <?php echo e(App\Http\Controllers\CommonController::getVendorName($product->vendor_id)); ?></a></li>
						   <?php endif; ?>
												 
						</div>
                    </div>
                </div>
 
		   </div>
        </section>
        
		
		
		 <section class="section-flashdeal--default ps-home--block">
            <div class="container">
                <div class="ps-block__header">
                    <h3 class="ps-block__title"><i class="icon-power"></i>Latest Products</h3><a class="ps-block__view" href="#">View all<i class="icon-chevron-right"></i></a>
                </div>
                <div class="flashdeal--content">
                   
 
                    <?php if(count($latest_product)): ?>  
                   <div class="owl-carousel flashdeal-content" data-owl-auto="false" data-owl-loop="false" data-owl-speed="5000" data-owl-gap="0" data-owl-nav="true" data-owl-dots="true" data-owl-item="6" data-owl-item-xs="2" data-owl-item-sm="2" data-owl-item-md="3" data-owl-item-lg="6" data-owl-duration="1000" data-owl-mousedrag="on">
                    
                    <?php $__currentLoopData = $latest_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ps-product--standard"><a href="<?php echo e(route('product_details',[$key->id])); ?>" target="_blank"><img class="ps-product__thumbnail" src="<?php echo e(url('public/'.$key->image)); ?>" alt="alt" /></a>
								<?php if($key->product_price  != $key->sale_price): ?>	
									<?php
										$product_regular_price = $key->product_price;
										$product_sale_price =  $key->sale_price;
										$discount_price =     (($product_regular_price - $product_sale_price ) * 100 ) / $product_regular_price;
									?>
								<span class="ps-badge ps-product__offbadge"><?php echo e(number_format($discount_price,0)); ?>% Off </span>
								<?php endif; ?>
							
							<div class="ps-product__content">
								<p class="ps-product-price-block">
										<?php if($key->product_price == $key->sale_price): ?>
											<span class="ps-product__price-default">₹<?php echo e($key->product_price); ?></span> 
										<?php else: ?>
											<span class="ps-product__sale">₹<?php echo e($key->sale_price); ?></span>
											<span class="ps-product__price">₹<?php echo e($key->product_price); ?></span>
										<?php endif; ?>
                                 </p>
								 
								
                                <p class="ps-product__type"><i class="icon-store"></i><?php echo e($key->vendor); ?></p>
								<a href="<?php echo e(route('product_details',[$key->id])); ?>">
                                    <h5 class="ps-product__name"><?php echo e($key->name); ?></h5>
                                </a>
                                <div class="ps-product__rating">
                                    <select class="rating-stars">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select><span>(0) </span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar bg-warning" role="progressbar" style="width: 0%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="ps-product__sold">
										<?php if($key->shipping_time == 'yes'): ?>
											<i class="icon-truck"></i>  Delivery : <?php echo e($key->estimate_time); ?>

										<?php endif; ?>
								</p>
                            </div>
                            <div class="ps-product__footer">
                                <div class="ps-product__box">
                                    <a href="<?php echo e(url('product',[$key->id])); ?>" target="_blank"><button class="ps-product__addcart"><i class="icon-cart"></i>View</button></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   </div>
                   <?php endif; ?>
                </div>
            </div>
        </section>
		<input type="hidden" id="is_size" value="<?= (count($product_size))?true:false ?>"> 
        <input type="hidden" id="size" value=""> 
        <input type="hidden" id="is_color" value="<?php echo e((count($product_colors))?true:false); ?>">
        <input type="hidden" value="<?php echo e($product->stock); ?>" id="stock">
        <input type="hidden" id="color" value="">
   </main>
   
	<script>
     $('.minus.ps-button.detail').click(function(){
       id = $(this).attr('data-id');
       quantity = $('#detail_input'+id).val();
       $.ajax({
            url:"/add_to_cart_ajax",
            data:{product_id:id,quantity:quantity},
            cache:false,
            success:function(response){
                var ress = jQuery.parseJSON(response);
                if (ress.success) {
                    $('.mini-cart').addClass('open');
                    $('.list-cart').html(ress.data);
                    $('.badge.bg-warning.cart').html(ress.count);
                    $('.col-6.text-right.total').html('₹'+ress.total);
                }else{
                    console.log(response);
                }
            }
        });
    });

     $('.plus.ps-button.detail').click(function(){
        amenties={}
       id = $(this).attr('data-id');
       quantity = $('#detail_input'+id).val();
       var stock = $('#stock').val();
       if ($('#is_size').val()) {
        if ($('#size').val()=='') {
            alert("Please select size.");
            $('#detail_input'+id).val(0);
            return false;
        }else{
            amenties["size"] = $('#size').val();
        }
       }

       if ($('#is_color').val()) {
        if ($('#color').val()=='') {
            alert("Please select color.");
            $('#detail_input'+id).val(0);
            return false;
        }else{
            amenties["color"] = $('#color').val();
        }
       }
       
       // if (quantity > $('#stock').val()) {
       //  alert("Only "+$('#stock').val()+" product available.");
       //  $('#detail_input'+id).val(0);
       //  return false;
       // }
        var jsonstr = JSON.stringify(amenties);
        
       $.ajax({
            url:"/add_to_cart_ajax",
            data:{product_id:id,quantity:quantity,amenties:jsonstr},
            cache:false,
            success:function(response){
                var ress = jQuery.parseJSON(response);
                if (ress.success) {
                $('.mini-cart').addClass('open');
                $('.list-cart').html(ress.data);
                $('.badge.bg-warning.cart').html(ress.count);
                $('.col-6.text-right.total').html('₹'+ress.total);
                }
            }
        });
    });   

     
    $('.color-list').on('click', function(){
	    $('.color-list').removeClass('active');
	    $(this).addClass('active');
        console.log($(this).attr('data-value'));
        $('#color').val($(this).attr('data-value'));
	});

    $('#product_size').change(function(){
        var value = $(this).val();
        var product_id = "<?php echo e($product->id); ?>";
        $('#size').val(value);
    });
get_cart();
function get_cart() {
    $.ajax({
        url:"/get_cart_ajax",
        cache:false,
        success:function(response){
            var ress = jQuery.parseJSON(response);
            if (ress.success) {
                $('.list-cart').html(ress.data);
                $('.badge.bg-warning.cart').html(ress.count);
                $('.col-6.text-right.total').html('â‚¹'+ress.total);
            }else{
                //console.log(response);
            }
        }
    });
}
get_wishlist();
function get_wishlist() {
    $.ajax({
        url:"/get_wishlist_ajax",
        cache:false,
        success:function(response){
            var ress = jQuery.parseJSON(response);
            if (ress.success) {
                $('.badge.bg-warning.wishlist').html(ress.count);
            }else{
                //console.log(response);
            }
        }
    });

}
    </script> 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/product_details.blade.php ENDPATH**/ ?>