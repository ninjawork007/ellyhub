<?php $__env->startSection('pagebodyclass'); ?>
full-width
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<nav class="amrcart-breadcrumb">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
    </span>Vendor Login
</nav>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card card-signin">
                        <div class="card-body registration__info">
                            <h5 class="card-title text-center">Vendor Log In</h5>
                            <?php echo $__env->make('alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if(Session::has('info')): ?>
                            <div class="alert alert-info alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <h6><i class="icon fa fa-warning"></i><a
                                        href="<?php echo e(url('vendor/resend-email')); ?>/<?php echo e(Session::get('email')); ?>"
                                        class="resend_email">Click here</a> for resend email.</h6>
                            </div>
                            <?php endif; ?>
                            <form method="post" action="<?php echo e(route('vendor_login')); ?>" data-parsley-validate="">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="type" value="vendor">
                                <div class="form-label-group  mb-3">
                                    <label for="inputEmail">Email address</label>
                                    <input class="form-control" type="email" placeholder="Enter Email " name="email" required="" data-parsley-trigger="change" value="<?php echo e(old('email')); ?>">
                                </div>

                                <div class="form-label-group  mb-3">
                                    <label for="inputPassword">Password</label>
                                    <input class="form-control" type="password" name="password" id="password" required="" placeholder="Password">
                                </div>

                                <div class="custom-checkbox mb-3">
                                    <label class="custom-control-label" for="customCheck1">
                                        <input type="checkbox" class="" id="customCheck1">
                                        Remember password</label>
                                </div>
                                <button class="btn ps-button btn-lg btn-primary btn-block text-uppercase mb-3" type="submit">Sign in</button>
                                <p>Not have account? <b><a class="main-color" href="<?php echo e(url('/vendor/register')); ?>">Register here</a></b></p>
                                <p>Forget Password? <b><a class="main-color" href="<?php echo e(url('/vendor/forget-password')); ?>">click here</a></b></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<script type="text/javascript">
$('body').on('click', '.resend_email', function() {
    alert($('input[name="email"]').val());
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/vendor_login.blade.php ENDPATH**/ ?>