<?php $__env->startSection('content'); ?>
<main class="no-main">
        <div class="ps-breadcrumb">
            <div class="container">
                <ul class="ps-breadcrumb__list">
                    <li class="active"><a href="index.html">Home</a></li>
                    <li><a href="javascript:void(0);">Order Detail</a></li>
                </ul>
            </div>
        </div>
         <section class="section--wishlist">
            <div class="container-fluid my-5 d-flex justify-content-center">
    <div class="card card-1" id="main_pr_div">
        <div class="card-header bg-white">
            <div class="media flex-sm-row flex-column-reverse justify-content-between ">
                
                <div class="col-auto text-center my-auto pl-0 pt-sm-4"> <img class="img-fluid my-auto align-items-center mb-0 pt-3" src="<?php echo e(url('public/assets/web/img/logo/bazarhat99-logo.png')); ?>" width="115" height="115">
                </div>
            </div>
        </div>
        <div class="card-header bg-white">
             <div class="col">
                    <p class="mb-1"> Name : <?php echo e($orders[0]->name); ?></p>
                    <p class="mb-1">Email : <?php echo e($orders[0]->email); ?></p>
                    <p class="mb-1">Phone: <?php echo e($orders[0]->phone); ?></p>
                    <p class="mb-1">Address:<?php echo e($orders[0]->street_address); ?>, <?php echo e($orders[0]->city); ?>, <?php echo e($orders[0]->country); ?> <?php echo e($orders[0]->zip); ?></p>
                </div>
        </div>
        <div class="card-body">
            <div class="row justify-content-between mb-3">
                <div class="col-auto">
                    <h6 class="color-1 mb-0 change-color">Receipt</h6>
                </div>
                <div class="col-auto "> <small>Order Id : <?php echo e($orders[0]->order_id); ?></small> </div>
            </div>
            <!-- loop row -->
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col">
                    <div class="card card-2">
                        <div class="card-body">
                            <div class="media">
                                <div class="sq align-self-center "> <img class="img-fluid my-auto align-self-center mr-2 mr-md-4 pl-0 p-0 m-0" src="<?php echo e(url('public/'.$key->image)); ?>" width="135" height="135" /> </div>
                                <div class="media-body my-auto text-right">
                                    <div class="row my-auto flex-column flex-md-row">
                                        <div class="col my-auto">
                                            <h6 class="mb-0"> <?php echo e($key->product_name); ?></h6>
                                        </div>
                                        <div class="col-auto my-auto"> <small>(x<?php echo e($key->product_quantity); ?>) </small></div>
                                        <div class="col my-auto">
                                            <h6 class="mb-0">&#8377;<?php echo e($key->sale_price); ?></h6>
                                        </div>

                                        <?php if($key->product_info): ?>
                                        <div class="col my-auto">
                                        <?php 
                                        $array = json_decode($key->product_info);
                                        if (isset($array->size)) {
                                            echo '<p>Size: '.$array->size.'</p>';
                                        }
                                        ?>
                                        </div>
                                        
                                        <?php 
                                        if (isset($array->color)) {
                                            echo '<div class="col my-auto"><p>Color: '.$array->color.'</p></div>';
                                        }
                                        ?>
                                        
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <hr class="my-3 ">
                            <div class="row">
                                <div class="col-md-3 mb-3"> </div>
                                <div class="col mt-auto">
                                    <div class="progress my-auto">
                                        <div class="progress-bar progress-bar rounded" style="width: <?php if($key->delivery_status=='pending'){ echo '1'; }else if($key->delivery_status=='dispatch'){ echo '50'; }else if($key->delivery_status=='delivered'){ echo '100'; }?>%" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <div class="media row justify-content-between ">
                                        <div class="col-auto text-right"><span> <small class="text-right mr-sm-2">Pending</small> <i class="fa fa-circle active"></i> </span></div>
                                        <div class="flex-col"> <span> <small class="text-right mr-sm-2">Dispatched</small><i class="fa fa-circle active"></i></span></div>
                                        <div class="col-auto flex-col-auto"><small class="text-right mr-sm-2">Delivered</small><span> <i class="fa fa-circle "></i></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- loop row end-->
            <div class="row mt-4">
                <div class="col">
                    <div class="row justify-content-between">
                        <div class="col-auto">
                            <p class="mb-1 text-dark"><b>Order Details</b></p>
                        </div>
                        <div class="flex-sm-col text-right col">
                            <p class="mb-1"><b>Delivery Charges</b></p>
                        </div>
                        <div class="flex-sm-col col-auto">
                            <p class="mb-1">&#8377;<?php echo e($delivery); ?></p>
                        </div>
                    </div>
                    <div class="row justify-content-between">
                        
                        <div class="flex-sm-col text-right col">
                            <p class="mb-1"><b>Total</b></p>
                        </div>
                        <div class="flex-sm-col col-auto">
                            <p class="mb-1">&#8377;<?php echo e($orders[0]->order_total); ?></p>
                        </div>
                    </div>
                    <div class="row justify-content-between">
                        <div class="flex-sm-col text-right col">
                            <p class="mb-1"> <b>Discount</b></p>
                        </div>
                        <div class="flex-sm-col col-auto">
                            <p class="mb-1">&#8377;<?php echo e($orders[0]->order_total-$orders[0]->after_discount_paid_by_customer); ?></p>
                        </div>
                    </div>
                    <!-- div class="row justify-content-between">
                        <div class="flex-sm-col text-right col">
                            <p class="mb-1"><b>GST 18%</b></p>
                        </div>
                        <div class="flex-sm-col col-auto">
                            <p class="mb-1">843</p>
                        </div>
                    </div> -->
                    
                </div>
            </div>
            <div class="row invoice ">
                <div class="col">
                    <p class="mb-1">Invoice Date : <?php echo e(date('d F, Y',strtotime($orders[0]->created_at))); ?></p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <div class="jumbotron-fluid">
                <div class="row justify-content-between ">
                    <div class="col-sm-auto col-auto my-auto"><img class="img-fluid my-auto align-self-center " src="<?php echo e(url('public/assets/web/img/logo/bazarhat99-logo.png')); ?>" width="115" height="115"></div>
                    <div class="col-auto my-auto ">
                        <h2 class="mb-0 font-weight-bold">TOTAL PAID</h2>
                    </div>
                    <div class="col-auto my-auto ml-auto">
                        <h1 class="display-3 ">&#8377; <?php echo e($orders[0]->after_discount_paid_by_customer); ?></h1>
                    </div>
                </div>
                <div class="row mb-3 mt-3 mt-md-0">
                   <button class="btn btn-primary" id="btn_print">Print</button>
                </div>
            </div>
        </div>
    </div>
</div>
        </section>
    </main>
<script type="text/javascript">
$("#btn_print").click(function () {
    var divToPrint=document.getElementById('main_pr_div');
    var newWin=window.open('','Print-Window');
    newWin.document.open();
    newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');
    newWin.document.close();
    setTimeout(function(){newWin.close();},10);
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/order_details.blade.php ENDPATH**/ ?>