<?php $__env->startSection('content'); ?>



      <nav class="amrcart-breadcrumb">
    <a href="https://bazarhat99.com">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
    </span> Wishlist
</nav>

         <div id="primary" class="content-area">
<main id="main" class="site-main">

            <div class="container">

                <h2 class="page__title">Wishlist</h2>

                <div class="wishlist__content">

                    <div class="wishlist__product">

                        <div class="wishlist__product--desktop">

                            <?php if(count($wishlist)): ?>

                            <table class="shop_table shop_table_responsive cart">

                                <thead>

                                    <tr>

                                        <th scope="col">Product</th>

                                        <th scope="col">Price</th>

                                        <th scope="col">Date</th>

                                        <th scope="col">Action</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr id="<?php echo e($key->id); ?>">

                                        <td data-title="Product" class="product-name">

                                            <a href="<?php echo e(url('/product/'.$key->product_id)); ?>">

                                                <img src="<?php echo e(url('public/'.$key->image)); ?>" style="max-width: 100px;">

                                                <?php echo e($key->name); ?>


                                            </a>

                                        </td>

                                        <td data-title="Price" class="product-price">₹<?php echo e($key->sale_price); ?></td>

                                        <td data-title="Date" class="product-price"><?php echo e(date('d F, Y',strtotime($key->created_at))); ?></td>

                                        <td data-title="Remove" class="product-price"><div class="wishlist__trash wishlist" data-id="<?php echo e($key->id); ?>"><a title="Remove this item icon-trash2 wishlist" class="remove" 
                                    href="#">×</a></div></td>

                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>

                            <?php else: ?>

                            <div class="text-center">

                                <img src="<?php echo e(url('/public/not-found.jpg')); ?>">

                                <p>No Wishlist Found.</p>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>
</main>
        </div>



<script type="text/javascript">

    $('.wishlist__trash.wishlist').click(function(){

        id = $(this).attr('data-id');

        if (confirm('Do you want to remove from wishlist?')) {

            $.ajax({

            url:'/remove_from_wishlist',

            data:{id:id},

            cache:false,

            success:function(res){

              if (res) {

                window.location.reload();

                // /$('#cartrow'+id+'').fadeOut(1200).css({'background-color':'#f2dede'});

              }

            }

          }); 

        }else{

            return false;

        }

    });

</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/929755.cloudwaysapps.com/gmpkuurdrk/public_html/resources/views/wishlist.blade.php ENDPATH**/ ?>