
<?php $__env->startSection('content'); ?>
<style>
body .banner-img {
    width: auto;
    max-width: -webkit-fill-available;
    border: 2px solid gray;
    padding: 5px;
	max-height: 200px;
}
</style>
<div class="main-panel">
        <div class="content-wrapper">
          <h4 class="card-title">
				<?php echo e(($banner->banner_type) == '1' ? 'Home Banner' : ''); ?> 
				<?php echo e(($banner->banner_type) == '2' ? 'Top Banner' : ''); ?> 
				<?php echo e(($banner->banner_type) == '3' ? 'Bottom Banner' : ''); ?> 
			</h4>						   
				
		   <a href="<?php echo e(route('banner_list')); ?>" class="btn btn-outline-info btn-sm"><i class="fa fa-arrow-left"></i></a></h4>
		   <a href="<?php echo e(route('edit_banner',[$banner->id])); ?>" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i></a>  </label>
							
		  
		   
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div class="card-body">
                    <div class="row">
					<div class="col-md-9">
							<?php if($banner->banner){?>
							<label class="col-form-label">Web Image</label><br>
								<img src="<?php echo e(url('public/'.$banner->banner)); ?>"    class="banner-img"/>
							<?php }?>
							<?php if($banner->m_banner){?>
							<label class="col-form-label">Mobile Image</label><br>
								<img src="<?php echo e(url('public/'.$banner->m_banner)); ?>"    class="banner-img"/>
							<?php }?>
                           
                        </div>
                       <div class="col-md-3">
							<label class="col-sm-12 col-form-label">Details :  
							<label class="col-sm-12 col-form-label">Title :  <?php echo e($banner->title); ?> </label>
							<label class="col-sm-12 col-form-label"> Type :
							           <?php echo e(($banner->banner_type) == '1' ? 'Home Banner' : ''); ?> 
								       <?php echo e(($banner->banner_type) == '2' ? 'Top Banner' : ''); ?> 
									   <?php echo e(($banner->banner_type) == '3' ? 'Bottom Banner' : ''); ?> </label>
							<label class="col-sm-12 col-form-label">URL :  <?php echo e($banner->url); ?> </label>
							<label class="col-sm-12 col-form-label">Status : 
												 <?php if($banner->status  == 'yes' ): ?> 
					<label class="btn btn-outline-primary btn-sm "> Active </label>
				<?php else: ?>
					<label class="btn btn-outline-danger btn-sm "> Inactive </label>
				<?php endif; ?> 
						   </label>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
        <script>
	  $( "body" ).addClass('sidebar-icon-only');
	  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/admin/banner/view.blade.php ENDPATH**/ ?>