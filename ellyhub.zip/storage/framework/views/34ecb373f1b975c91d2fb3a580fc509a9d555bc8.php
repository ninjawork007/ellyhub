<!DOCTYPE html>
<html>
<head>
	<title>bazarhat99</title>
</head>
<body>
<?php echo $data['html']; ?>

</body>
</html><?php /**PATH /home/bazarhat99/public_html/resources/views/email/register.blade.php ENDPATH**/ ?>