<?php $__env->startSection('pagebodyclass'); ?>
full-width
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<nav class="amrcart-breadcrumb">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
    </span> My Profile
</nav>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <section class="section--wishlist">
            <div class="container">
                <?php echo $__env->make('common.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">

                    <div class="col-12 col-lg-5">
                        <div class="card p-3">
                            <div class="d-flex align-items-center">
                                <div class="image">
                                    <?php if(Auth::user()->image): ?>
                                    <img src="<?php echo e(url('public/'.Auth::user()->image)); ?>" class="rounded" width="155">
                                    <?php else: ?>
                                    <img src="https://www.atmeplay.com/images/users/avtar/avtar_nouser.png"
                                        class="rounded" width="155">
                                    <?php endif; ?>
                                </div>
                                <div class="ml-3 w-100">
                                    <h4 class="mb-0 mt-0"><?php echo e(Auth::user()->name); ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-7">
                        <div class="checkout__form">
                            <form method="post" data-parsley-validate="" action="<?php echo e(route('update_profile')); ?>"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col-12 col-lg-6 form-group--block">
                                        <label>Name: <span>*</span></label>
                                        <input class="form-control" type="text" required=""
                                            value="<?php echo e(Auth::user()->name); ?>" name="name">
                                    </div>
                                    <div class="col-12 col-lg-6 form-group--block">
                                        <label>Email<span>*</span></label>
                                        <input class="form-control" type="email" required=""
                                            value="<?php echo e(Auth::user()->email); ?>" name="email" readonly="">
                                    </div>
                                    <div class="col-12 form-group--block">
                                        <label>Mobile</label>
                                        <input class="form-control" type="text" value="<?php echo e(Auth::user()->mobile); ?>"
                                            name="mobile" required="">
                                    </div>
                                    <div class="col-12 form-group--block">
                                        <label>Profile</label>
                                        <input class="form-control" type="file" name="file">
                                    </div>
                                    <button class="checkout__order"> Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ellyhub\resources\views/user_profile.blade.php ENDPATH**/ ?>