<?php $__env->startSection('content'); ?>

<div class="main-panel">

        <div class="content-wrapper">

          <h4 class="card-title">Brand List</h4>

          <div class="row">

            <div class="col-lg-12 grid-margin stretch-card">



              <div class="card">

                <?php echo $__env->make('alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<div class="error"></div>

                <div class="card-body">

                  <div class="col-md-12">

                    <a href="<?php echo e(route('add_brand')); ?>" class="btn btn-outline-secondary btn-fw text-right"><i class="fa fa-plus"></i></a>

                  </div>

                  <div class="table-responsive">



                    <table class="table table-striped">

                      <thead>

                        <tr>

                          <th>Image</th>

                          <th>Name</th>

                          <th>Status </th>

                          <th>Feature </th>

                          <th>Action</th>

                        </tr>

                      </thead>

                      <tbody>

                        <?php if($brand): ?>

						<?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr id="<?php echo e($key->id); ?>">

                          <td>  

						  <?php if($key->banner){?>  <img src="<?php echo e(url('public/'.$key->banner)); ?>" alt="image" class="bg-light" /><?php }?>

							</td>

                           <td> <?php echo e($key->title); ?></td>

                          

							<td> 

						       <select class="form-control"  name="status" id="status">

									    <option value="yes"  data-id="<?php echo e($key->id); ?>" data-name="status"   <?php echo e(($key->status) == 'yes' ? 'selected' : ''); ?> >Active</option>

										<option value="no" data-id="<?php echo e($key->id); ?>" data-name="status" <?php echo e(($key->status) == 'no' ? 'selected' : ''); ?> >Inactive</option>

							   </select>

						  </td>

                          

						  <td> 

						       <select class="form-control"  name="feature" id="feature">

									    <option value="yes"  data-id="<?php echo e($key->id); ?>" data-name="feature" <?php echo e(($key->feature) == 'yes' ? 'selected' : ''); ?> >Yes</option>

										<option value="no" data-id="<?php echo e($key->id); ?>" data-name="feature" <?php echo e(($key->feature) == 'no' ? 'selected' : ''); ?> >No</option>

							   </select>

						 </td>

                          <td>

                           <div>

                               <a href="<?php echo e(route('view_brand',[$key->id])); ?>" class="btn btn-outline-primary btn-sm"><i class="fa fa-eye"></i></a>

                               <a href="<?php echo e(route('edit_brand',[$key->id])); ?>" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i></a>

                               <a href="javascript:;" class="btn btn-outline-danger btn-sm" onclick="delete_row('<?php echo e($key->id); ?>','brand')"><i class="fa fa-trash"></i></a>

                            </div>

                          </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                      </tbody>

                    </table>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

       

      </div>

	  <script>


	    $('body').on('change','select',function(){

		   $('.error').html('');

           var id =  $(this).find(':selected').data('id');

           var name =  $(this).find(':selected').data('name');

           var value =  $(this).find(':selected').val();

 

		  $.ajax({

			url:"<?php echo e(route('brand_status')); ?>",

			data:{id:id,value:value,name:name},

			cache:false,

			success:function(response){

				if(response == 1){

				     $('.error').html('<div class="alert alert-info alert-dismissible fade show" role="alert">Status update successfully.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');

				} else {

			         $('.error').html('<div class="alert alert-error alert-dismissible fade show" role="alert">error while updating status!!!<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');

			          $(name).prop('selectedIndex',0);

			  }

			}

		  });

});  

	  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/admin/brand/list.blade.php ENDPATH**/ ?>