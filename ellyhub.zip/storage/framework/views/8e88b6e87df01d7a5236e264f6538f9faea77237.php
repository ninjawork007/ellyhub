

<?php $__env->startSection('content'); ?>
<main class="no-main">
        <div class="ps-breadcrumb">
            <div class="container">
                <ul class="ps-breadcrumb__list">
                    <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="javascript:void(0);">success</a></li>
                </ul>
            </div>
        </div>
        <section class="section--shopping-cart">
            <div class="container shopping-container">
                <div class="shopping-cart__content">
                   <div class="row m-0">
                        <div class="col-md-12 notfound text-center">
                            <img src="<?php echo e(url('public/success.gif')); ?>" width="200px">
                            <br>
                            <p>Order successfull Placed</p>
                            <a class="btn" href="<?php echo e(url('/orders')); ?>">Go To Orders</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/success.blade.php ENDPATH**/ ?>