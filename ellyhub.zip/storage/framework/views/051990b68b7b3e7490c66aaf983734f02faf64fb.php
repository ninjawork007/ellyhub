<?php $__env->startSection('content'); ?>

<main class="no-main">

        <div class="ps-breadcrumb">

            <div class="container">

                <ul class="ps-breadcrumb__list">

                    <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>

                    <li><a href="javascript:void(0);">Wishlist</a></li>

                </ul>

            </div>

        </div>

         <section class="section--wishlist">

            <div class="container">

                <h2 class="page__title">Wishlist</h2>

                <div class="wishlist__content">

                    <div class="wishlist__product">

                        <div class="wishlist__product--desktop">

                            <?php if(count($wishlist)): ?>

                            <table class="table">

                                <thead class="wishlist__thead">

                                    <tr>

                                        <th scope="col">Product</th>

                                        <th scope="col">Price</th>

                                        <th scope="col">Date</th>

                                        <th scope="col">Action</th>

                                    </tr>

                                </thead>

                                <tbody class="wishlist__tbody">

                                    <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr id="<?php echo e($key->id); ?>">

                                        <td>

                                            <a href="<?php echo e(url('/product/'.$key->product_id)); ?>">

                                                <img src="<?php echo e(url('public/'.$key->image)); ?>" style="max-width: 100px;">

                                                <?php echo e($key->name); ?>


                                            </a>

                                        </td>

                                        <td>₹<?php echo e($key->sale_price); ?></td>

                                        <td><?php echo e(date('d F, Y',strtotime($key->created_at))); ?></td>

                                        <td><div class="wishlist__trash wishlist" data-id="<?php echo e($key->id); ?>"><i class="icon-trash2"></i></div></td>

                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>

                            <?php else: ?>

                            <div class="text-center">

                                <img src="<?php echo e(url('/public/not-found.jpg')); ?>">

                                <p>No Wishlist Found.</p>

                            </div>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            </div>

        </section>

    </main>

<script type="text/javascript">

    $('.wishlist__trash.wishlist').click(function(){

        id = $(this).attr('data-id');

        if (confirm('Do you want to remove from wishlist?')) {

            $.ajax({

            url:'/remove_from_wishlist',

            data:{id:id},

            cache:false,

            success:function(res){

              if (res) {

                window.location.reload();

                // /$('#cartrow'+id+'').fadeOut(1200).css({'background-color':'#f2dede'});

              }

            }

          }); 

        }else{

            return false;

        }

    });

</script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bazarhat99/public_html/resources/views/wishlist.blade.php ENDPATH**/ ?>