
<?php $__env->startSection('pagebodyclass'); ?>
full-width <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<nav class="amrcart-breadcrumb">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
    </span> Products
</nav>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <h4 class="title"><span class="main-color"><?php echo e($products->count()); ?></span> Product Found</h4>
        <div class="category-products-list columns-5">
            <div class="products">
                <?php if($products->count()): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product">
                    <div class="amr-add-to-wishlist">
                        <a onclick="add_wishlist('<?php echo e($key->id); ?>','wishlist')" href="JavaScript:void(0);" rel="nofollow"
                            class="add_to_wishlist"> Add to Wishlist</a>
                    </div>
                    <a class="amr-LoopProduct-link" href="<?php echo e(route('product_details',[$key->id])); ?>">
                        <?php if($key->discount_type): ?>
                        <span class="onsale">
                            <?php if($key->discount): ?>
                            <span class="amr-Price-amount amount">
                                <?php if($key->discount_type=='flat'): ?>
                                <?php echo e('Rs '. $key->discount); ?> off
                                <?php else: ?>
                                <?php echo e($key->discount); ?>% off
                                <?php endif; ?>
                            </span>
                            <?php endif; ?>
                        </span>
                        <?php endif; ?>
                        <div class="amr-product-img">
                            <img src="<?php echo e(url('public/'.$key->image)); ?>" alt="<?php echo e($key->name); ?>">
                        </div>
                        <div class="pro-info">
                            <h2 class="amr-loop-product-title"><?php echo e($key->name); ?></h2>
                            <span class="price">
                                <ins>
                                    <span class="amount"> ₹<?php echo e($key->sale_price); ?></span>
                                </ins>
                                <?php if($key->sale_price != $key->mrp_price): ?>
                                <del>
                                    <span class="amount">₹<?php echo e($key->mrp_price); ?></span>
                                </del>
                                <?php endif; ?>
                                <span class="amount"></span>
                            </span>
                            <!-- <div><?php echo e($key->vendor_name); ?></div> -->
                        </div>

                    </a>
                    <div class="hover-area">
                        <a class="button add_to_cart_button" href="<?php echo e(url('product',[$key->id])); ?>" rel="nofollow">View
                            Product</a>
                        <?php if($key->shipping_time == 'yes'): ?>
                        <p class="amr-shipping-estimate">
                            <i class="icon amr-order-tracking"></i> Delivery - <?php echo e($key->estimate_time); ?>

                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/products.blade.php ENDPATH**/ ?>