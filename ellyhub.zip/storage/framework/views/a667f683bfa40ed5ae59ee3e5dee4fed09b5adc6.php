<?php $__env->startSection('pagebodyclass'); ?>
full-width
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<nav class="amrcart-breadcrumb">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
    </span> Forget Password
</nav>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <div class="row">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card card-signin">
                        <div class="card-body registration__info">
                            <h5 class="card-title text-center">Forget Password</h5>
                            <?php echo $__env->make('alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="error_"></div>
                            <form method="post" action="<?php echo e(route('send_password')); ?>" data-parsley-validate="">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="type" value="<?php echo e($type); ?>">
                                <div class="form-label-group  mb-3">
                                    <label for="inputEmail">Email address</label>
                                    <input class="form-control" type="email" placeholder="Enter Email" name="email"
                                        required="" data-parsley-trigger="change" value="<?php echo e(old('email')); ?>" autofocus>
                                </div>
                                <button class="btn ps-button btn-lg btn-primary btn-block text-uppercase  mb-3" type="submit">Reset Password</button>
                                
                                <p>Login? <b><a class="main-color" href="<?php echo e(url('/user/login')); ?>">click here</a></b></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ellyhub\resources\views/forget_password.blade.php ENDPATH**/ ?>