<?php if(Session::has('danger')): ?>
<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h6><i class="icon fa fa-ban"></i> Error: <?php echo e(Session::get('danger')); ?></h6>
</div>
<?php endif; ?> <?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h6><i class="icon fa fa-check"></i> Success: <?php echo e(Session::get('success')); ?></h6>
</div>
<?php endif; ?> <?php if(Session::has('warning')): ?>
<div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h6><i class="icon fa fa-warning"></i> Warning: <?php echo e(Session::get('warning')); ?></h6>
</div>
<?php endif; ?>
<?php if(Session::has('info')): ?>
<div class="alert alert-info alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h6><i class="icon fa fa-warning"></i> Warning: <?php echo e(Session::get('info')); ?></h6>
</div>
<?php endif; ?><?php /**PATH /home/amrkartroot/public_html/multivendor/resources/views/alerts.blade.php ENDPATH**/ ?>