<?php $__env->startSection('content'); ?>
<div class="main-panel">
        <div class="content-wrapper">
          <h4 class="card-title">General Setting</h4>
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <?php echo $__env->make('alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amrkartroot/public_html/multivendor/resources/views/admin/frontpage/general.blade.php ENDPATH**/ ?>