<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin | Bharat Bazar</title>
  <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/vendors/ti-icons/css/themify-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('public/assets/admin/css/layout-light/style.css')); ?>">
  <link rel="shortcut icon" href="<?php echo e(url('public/assets/admin/images/favicon.png')); ?>" />
  <link rel="shortcut icon" href="<?php echo e(url('public/assets/parsley/parsley.css')); ?>" />
</head>
<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <?php echo $__env->make('alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">

              <div class="brand-logo text-center">
                <img src="<?php echo e(url('public/assets/logo/logo.png')); ?>" alt="logo">
              </div>
              <form class="pt-3" method="post" data-parsley-validate="" action="<?php echo e(route('attempt_login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input type="email" class="form-control form-control-lg" placeholder="Email" name="email" required="">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" placeholder="Password" name="password" required="">
                </div>
                <div class="mt-3">
                  <button type="submit" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn">SIGN IN</button>
                </div>
                <div class="my-2 d-flex justify-content-between align-items-center">
                  <a href="#" class="auth-link text-black">Forgot password?</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="<?php echo e(url('public/assets/admin/vendors/js/vendor.bundle.base.js')); ?>"></script>

  <script src="<?php echo e(url('public/assets/admin/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/hoverable-collapse.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/template.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/settings.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/admin/js/todolist.js')); ?>"></script>
  <script src="<?php echo e(url('public/assets/parsley/parsley.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/bazarhat99/public_html/resources/views/admin/login.blade.php ENDPATH**/ ?>