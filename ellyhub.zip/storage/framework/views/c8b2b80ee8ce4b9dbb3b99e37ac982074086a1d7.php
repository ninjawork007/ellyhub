

<?php $__env->startSection('content'); ?>
<main class="no-main">
        <nav class="amrcart-breadcrumb">
    <a href="<?php echo e(url('/')); ?>">Home</a>
    <span class="delimiter">
        <i class="icon amr-breadcrumbs-arrow-right"></i>
        
    </span>
   <?php echo e($page->type); ?>

</nav>
        <section class="section--contact">
            <div class="container">
                <h2 class="page__title text-center"><?php echo e($page->type); ?></h2>
                <div class="contact__content">
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $page->description; ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>		
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/page.blade.php ENDPATH**/ ?>