<?php $__env->startSection('content'); ?>
<main class="no-main">
        <div class="ps-breadcrumb">
            <div class="container">
                <ul class="ps-breadcrumb__list">
                    <li class="active"><a href="index.html">Home</a></li>
                    <li><a href="javascript:void(0);">Past orders</a></li>
                </ul>
            </div>
        </div>
         <section class="section--wishlist">
            <div class="container">
                <h2 class="page__title">Running orders</h2>
                <div class="wishlist__content">
                    <div class="wishlist__product">
                        <div class="wishlist__product--desktop">
                            <?php if(count($orders)): ?>
                            <table class="table">
                                <thead class="wishlist__thead">
                                    <tr>
                                        <!-- <th scope="col"></th> -->
                                        <th scope="col">Order Id</th>
                                        <th scope="col">Total Paid</th>
                                        <th scope="col">Total Products</th>
                                        <th scope="col">Payment Method</th>
                                        <th scope="col">Payment Status</th>
                                        <th scope="col">Order Status</th>
                                    </tr>
                                </thead>
                                <tbody class="wishlist__tbody">
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="<?php echo e($key->order_id); ?>">
                                        <!-- <td>
                                            <div class="wishlist__trash"><i class="icon-trash2"></i></div>
                                        </td> -->
                                        <td><a href="<?php echo e(route('order_detail',[base64_encode($key->order_id)])); ?>"><?php echo e($key->order_id); ?></a></td>
                                        <td>₹<?php echo e($key->after_discount_paid_by_customer); ?></td>
                                        <td><?php echo e($key->total); ?></td>
                                        <td><?php echo e($key->payment_method); ?></td>
                                        <td><?php echo e($key->payment_status); ?></td>
                                        <td><?php echo e($key->order_status); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <div class="text-center">
                                <img src="<?php echo e(url('/public/not-found.jpg')); ?>">
                                <p>No Order Found.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <h2 class="page__title">Complete orders</h2>
                <div class="wishlist__content">
                    <div class="wishlist__product">
                        <div class="wishlist__product--desktop">
                            <?php if(count($completed)): ?>
                            <table class="table">
                                <thead class="wishlist__thead">
                                    <tr>
                                        <!-- <th scope="col"></th> -->
                                        <th scope="col">Order Id</th>
                                        <th scope="col">Total Paid</th>
                                        <th scope="col">Total Products</th>
                                        <th scope="col">Payment Method</th>
                                        <th scope="col">Payment Status</th>
                                        <th scope="col">Order Status</th>
                                    </tr>
                                </thead>
                                <tbody class="wishlist__tbody">
                                    <?php $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="<?php echo e($key->order_id); ?>">
                                        <!-- <td>
                                            <div class="wishlist__trash"><i class="icon-trash2"></i></div>
                                        </td> -->
                                        <td><a href="<?php echo e(route('order_detail',[base64_encode($key->order_id)])); ?>"><?php echo e($key->order_id); ?></a></td>
                                        <td>₹<?php echo e($key->after_discount_paid_by_customer); ?></td>
                                        <td><?php echo e($key->total); ?></td>
                                        <td><?php echo e($key->payment_method); ?></td>
                                        <td><?php echo e($key->payment_status); ?></td>
                                        <td><?php echo e($key->order_status); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <div class="text-center">
                                <img src="<?php echo e(url('/public/not-found.jpg')); ?>">
                                <p>No Order Found.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/guest_orders.blade.php ENDPATH**/ ?>