<?php $__env->startSection('content'); ?>
<style type="text/css">

button.checkout__order:disabled {

    background-color: #04094bbf;

}

input#coupen_code { text-transform: uppercase; }

.checkout__label.text-green { color: green;}

..checkout__label.discount{color: green;}

</style>

    <main class="no-main">

        <div class="ps-breadcrumb">

            <div class="container">

                <ul class="ps-breadcrumb__list">

                    <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>

                    <li><a href="javascript:void(0);">Checkout</a></li>

                </ul>

            </div>

        </div>

        <section class="section--checkout">

            <div class="container">

                <h2 class="page__title">Checkout</h2>

                <div class="error_div"></div>

                <?php if(!$cart->isEmpty()): ?>

                <div class="checkout__content">

                    <div class="checkout__header">

                        <div class="row">

                            <div class="col-12 col-lg-7">



                                <?php if(!Auth::user()): ?>

                                <div class="checkout__header__box">

                                    <p><i class="icon-user"></i>Returning customer? <a href="#" data-toggle="modal" data-target="#login_modal">Click here to login</a></p><i class="icon-chevron-down"></i>

                                </div>

                                <?php endif; ?>

                            </div>

                            <div class="col-12 col-lg-5">

                                <div class="checkout__header__box">

                                    <p><i class="icon-tags"></i>Have a coupon? <a href="javascript:;" onclick="show_coupen_div()">Click here to renter your code</a></p><i class="icon-chevron-down"></i>

                                </div>

                                <div class="coupen d-none">

                                    <div class="col-12 col-lg-12 form-group--block mt-3">

                                        <input class="form-control" type="text" id="coupen_code" placeholder="Enter coupen code">

                                        <small class="error_couen text-danger"></small>

                                        <button class="checkout__order" onclick="apply_coupen()">Apply Coupen</button>

                                    </div>

                                    

                                </div>

                            </div>

                        </div>

                    </div>

                    <form method="post" action="<?php echo e(route('make_order')); ?>" data-parsley-validate="" id="order_form">

                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="userid" id="userid" value="<?php echo e(session('userid')); ?>">

                        <input type="hidden" name="is_coupen" id="is_coupen" value="no">
                        <input type="hidden" name="is_wallet" id="is_wallet" value="no">
                        <input type="hidden" name="apply_code" id="apply_code">

                        <input type="hidden" name="shipping_amount" id="shipping_amount" value="<?php echo e(($shipping_amount->shipping_amount)?$shipping_amount->shipping_amount:0); ?>">

                        <input type="hidden" name="payment_type" id="payment_type" value="cash">

                        <input type="hidden" name="order_total_before" id="order_total_before" value="<?php echo e($total+$shipping_amount->shipping_amount); ?>">

                        <input type="hidden" name="order_total" id="order_total" value="<?php echo e($total+$shipping_amount->shipping_amount); ?>">

                        <input type="hidden" name="rzp_id" id="rzp_id">
                        <input type="hidden" id="wallet_balance" name="wallet_balance" value="<?php echo e(Auth::user()->balance); ?>">
                        <input type="hidden" id="remain_wallet" name="remain_wallet" value="">
                        <input type="hidden" id="wallet_balance_used" name="wallet_balance_used" value="">
                    <div class="row" id="maindiv">

                        <div class="col-12 col-lg-7">

                            <h3 class="checkout__title">Billing Details</h3>

                            <div class="checkout__form">

                                

                                    <div class="form-row">

                                        <div class="col-12 col-lg-6 form-group--block">

                                            <label>Name: <span>*</span></label>

                                            <input class="form-control" type="text" required name="name" value="<?php echo e(@Auth::user()->name); ?>">

                                        </div>

                                        <div class="col-12 col-lg-6 form-group--block">

                                            <label>Phone: <span>*</span></label>

                                            <input class="form-control" type="text" required name="phone" value="<?php echo e(@Auth::user()->mobile); ?>" >

                                        </div>

                                        <div class="col-12 form-group--block">

                                            <label>Email address: <span>*</span></label>

                                            <input class="form-control" type="email" required name="email" value="<?php echo e(@Auth::user()->email); ?>">

                                        </div>

                                        <?php if(!$address->isEmpty()): ?>

                                        <div class="col-12 form-group--block">

                                            <div class="slider address-items">

                                                <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div id="<?php echo e($key->id); ?>" class="address_">

                                                    <label class="address-col">

                                                        <div class="address-name"><?php echo e(ucfirst($key->address_type)); ?></div>

                                                        <address><?php echo e($key->street); ?></address>

                                                    </label>

                                                </div>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </div>

                                        </div>

                                    <?php endif; ?>

                                <h3 class="checkout__title">Shipping Address</h3>

                                        <div class="col-12 form-group--block">

                                            <label>House no./ Street address: <span>*</span></label>

                                            <input class="form-control" type="text" placeholder="House number and street name" name="street_address" required="">

                                        </div>

                                        <div class="col-12 form-group--block">

                                            <label>Postcode/ ZIP (optional)</label>

                                            <input class="form-control" type="text" name="zip" required="">

                                        </div>

                                        <div class="col-12 form-group--block">

                                            <label>Town/ City: <span>*</span></label>

                                            <input class="form-control" type="text" required name="city">

                                        </div>

                                        <div class="col-12 form-group--block">

                                            <label>Country: <span>*</span></label>

                                            <input class="form-control" type="text" required name="country">

                                        </div>

                                        <div class="col-12 form-group--block <?php if(!Auth::user()){ echo 'd-none';}?>">

                                            <input id="save_address" class="form-check-input" type="checkbox" name="save_address"> 

                                            <label for="save_address" class="label-checkbox">Do you want to save this address?</label>

                                        </div>

                                        <?php if(!Auth::user()): ?>

                                        <div class="col-12 form-group--block">

                                            <input id="create_account" class="form-check-input" type="checkbox" name="create_account"> 

                                            <label for="create_account" class="label-checkbox">Create an account?</label>

                                        </div>

                                        <?php endif; ?>

                                        <div class="col-12 form-group--block">

                                            <label>Order notes (optional)</label>

                                            <textarea class="form-control" placeholder="Note about your orders, e.g special notes for delivery." name="notes"></textarea>

                                        </div>

                                    </div>

                            </div>

                        </div>

                        <div class="col-12 col-lg-5">

                            <h3 class="checkout__title">Your Order</h3>

                            <div class="checkout__products">

                                <div class="row">

                                    <div class="col-8">

                                        <div class="checkout__label">PRODUCT</div>

                                    </div>

                                    <div class="col-4 text-right">

                                        <div class="checkout__label">TOTAL</div>

                                    </div>

                                </div>

                                <div class="checkout__list">

                                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="checkout__product__item">

                                        <div class="checkout-product">

                                            <div class="product__name"><?php echo e($key->product_name); ?><span>(x<?php echo e($key->product_quantity); ?>)</span></div>

                                            

                                        </div>

                                        <div class="checkout-price">&#x20B9;<?php echo e($key->total_price); ?></div>

                                    </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <div class="row">

                                    <div class="col-8">

                                        <div class="checkout__label">Subtotal</div>

                                    </div>

                                    <div class="col-4 text-right">

                                        <div class="checkout__label">&#x20B9;<?php echo e($total); ?></div>

                                    </div>

                                </div>

                                <hr>

                                <div class="row discount d-none">

                                    <div class="col-8">

                                        <div class="checkout__label text-green">Discount</div>

                                    </div>

                                    <div class="col-4 text-right">

                                        <div class="checkout__label discount"></div>

                                    </div>

                                </div>

                                <div class="row shipping_wallet_div">
                                    <div class="col-8">
                                        <div class="checkout__label">Shipping</div>
                                    </div>
                                    <div class="col-4 text-right">
                                        <div class="checkout__label shipping">+ &#x20B9;<?php echo e($shipping_amount->shipping_amount); ?></div>
                                    </div>
                                </div>

                                

                                <div class="row">

                                    <div class="col-8">

                                        <div class="checkout__total">Total</div>

                                    </div>

                                    <div class="col-4 text-right">

                                        <div class="checkout__money final_amount">&#x20B9;<?php echo e($total+$shipping_amount->shipping_amount); ?></div>

                                    </div>
                                </div>

                            </div>

                            <div class="checkout__payment">
                                <div class="checkout__label mb-3">SELECT PAYMENT</div>
                                <div class="form-group--block">
                                    <input class="form-check-input" type="radio" value="cash" name="payment_type" checked="checked">
                                    <label class="label-checkbox" for="checkboxCash"><b class="text-heading">Cash on delivery</b></label>
                                </div>
                                <div class="checkout__payment__detail">Pay with cash upon delivery

                                    <div class="triangle-box">

                                        <div class="triangle"></div>

                                    </div>

                                </div>

                                <div class="form-group--block">

                                    <input class="form-check-input" type="radio" name="payment_type" value="online">

                                    <label class="label-checkbox" for="checkboxPaypal"><b class="text-heading">Online </b></label>

                                </div>

                            </div>

                            <p>Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <span class="text-success">privacy policy.</span></p>

                            <div class="form-group--block">

                                <input class="form-check-input" type="checkbox" id="checkboxAgree" value="agree" required="">

                                <label class="label-checkbox" for="checkboxAgree"><b class="text-heading">I have read and agree to the website

                      <u class="text-success">terms and conditions  </u><span>*</span></b></label>

                            </div><button class="checkout__order" type="submit">Place an order</button>

                        </div>

                    </div>

                </form>

                </div>

                <?php else: ?>

                <div class="row m-0">

                        <div class="col-md-12 notfound text-center">

                            <img src="<?php echo e(url('public/emptycart.png')); ?>" width="200px">

                            <br>

                            <a class="btn" href="<?php echo e(url('/')); ?>">Shop Now</a>

                        </div>

                    </div>

                <?php endif; ?>



            </div>

        </section>

    </main>

  <script src="https://checkout.razorpay.com/v1/checkout.js"></script>

    <script type="text/javascript">

        jQuery(document).ready(function() {

            jQuery('.address-items').slick({

              infinite: true,

              slidesToShow: 3,

              slidesToScroll: 1

            });

            jQuery('.address-items label.address-col').click(function(){

                jQuery('.address-items label.address-col').removeClass("active");

                jQuery(this).addClass("active");

            });

        });



        function show_coupen_div() {

            $('.coupen.d-none').removeClass('d-none');

        }



        function apply_coupen(){

            if ($.trim($('#coupen_code').val())=='') {

                $('.error_couen').html('Please enter coupen code.');

                return false;

            }

            $('.error_couen').html('');

            // $('.checkout__order').attr('disabled',true);

            // $('.checkout__order').html('Please wait...');

        $.ajax({

            url:"<?php echo e(url('apply_coupen')); ?>",

            data:{coupen:$.trim($('#coupen_code').val()),userid:$('#userid').val()},

            cache:false,

            success:function(response){

                var ress = JSON.parse(response);

                if (ress.success) {

                    $('.final_amount').html('₹'+ress.data.final_price);

                    $('.row.discount').removeClass('d-none');

                    $('.checkout__label.discount').html('- ₹'+ress.data.total_discount);

                    $('html, body').animate({

                        scrollTop: $("#maindiv").offset().top

                    }, 2000);

                    $('#is_coupen').val('yes');

                    $('#apply_code').val($('#coupen_code').val());

                   $('#order_total').val(ress.data.final_price);

                }else{

                     $('.error_couen').html(ress.message);

                }

            }

        });

        }



        $('input[name="payment_type"]').click(function(){

            $('#payment_type').val($(this).val());

        });



        $('#order_form').submit(function(e){

            e.preventDefault()
            var totalAmount = $('#order_total').val();
            if (!$('#order_form').parsley().validate()) {

                return false;

            }

            if (!totalAmount) {
                $('#order_form')[0].submit();
                return false;
            }

            if ($('#payment_type').val()=='cash') {

                $('#order_form')[0].submit();

                return false;

            }

            

            var final_amount_paid = totalAmount-$('#wallet_balance_used').val();
            final_amount_paid = final_amount_paid.toFixed(2);
            var product_id =  'BH123';

            var options = {

           "key": "<?php echo e(env('RAZOR_KEY')); ?>",

           "amount": (final_amount_paid*100), // 2000 paise = INR 20

           "name": "Bazarhat99",

           "image": "<?php echo e(url('public/assets/web/img/logo/bazarhat99-logo.png')); ?>",

           "handler": function (response){

            $('#rzp_id').val(response.razorpay_payment_id);

            $('#order_form')[0].submit();

           },

          "prefill": {

              "name": "",

              "contact": "",

              "email":   "",

           },

           "theme": {

               "color": "#e68306"

           }

         };

            var rzp1 = new Razorpay(options);

            rzp1.open();

            e.preventDefault();

        });
        $(document).on('click', '.address_', function() {
            addressid = $(this).attr('id');
            $.ajax({
                url:"<?php echo e(route('get_address')); ?>",
                data:{id:addressid},
                cache:false,
                success:function(response){
                    var ress = JSON.parse(response);
                    $('input[name="street_address"]').val(ress.data.street);
                    $('input[name="zip"]').val(ress.data.zip);
                    $('input[name="city"]').val(ress.data.town);
                    $('input[name="country"]').val(ress.data.country);
                }
            });
          });

        $(function(){
            apply_wallet();
        });
        function apply_wallet(){
            var order_total = $('#order_total').val();
            var wallet_balance = $('#wallet_balance').val();
            if (!wallet_balance) {
                console.log("no wallet balance");
                return false;
            }
            $('#is_wallet').val('yes');
            if (order_total > wallet_balance) {
                var after_discount = order_total-wallet_balance;
                var after_dicount_remain_wallet = 0;
                var wallet_used = wallet_balance;
            }else{
                var after_discount = 0;
                var after_dicount_remain_wallet = wallet_balance-order_total;
                var wallet_used = wallet_balance-after_dicount_remain_wallet;
            }

            //$('#order_total').val(after_discount);
            $('#wallet_balance').val(after_dicount_remain_wallet);
            $('.final_amount').html('₹'+after_discount.toFixed(2));
            $('.shipping_wallet_div').append('<div class="col-8 wallet_div"><div class="checkout__label">Wallet</div></div><div class="col-4 text-right wallet_div"><div class="checkout__label wallet">- ₹'+wallet_used+'</div></div>');
            if (!wallet_balance) {
                $('.checkout__payment').hide();
            }
            
            $('#payment_type').val('wallet');
            $('#wallet_balance_used').val(wallet_used);
            $('#remain_wallet').val(after_dicount_remain_wallet);
        }
    </script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bazarhat99/public_html/resources/views/checkout.blade.php ENDPATH**/ ?>