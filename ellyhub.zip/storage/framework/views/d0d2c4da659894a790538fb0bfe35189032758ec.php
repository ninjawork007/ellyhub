<!DOCTYPE html>
<html>
<head>
	<title>bazarhat99</title>
</head>
<body>
<?php echo $data['html']; ?>

</body>
</html><?php /**PATH /home/576636.cloudwaysapps.com/xqmnczxnwc/public_html/resources/views/email/register.blade.php ENDPATH**/ ?>