<?php $__env->startSection('content'); ?>

<div class="main-panel">

        <div class="content-wrapper">

          <h4 class="card-title">Sub Category</h4>

          <div class="row">

            <div class="col-lg-12 grid-margin stretch-card">



              <div class="card">

                <?php echo $__env->make('alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="card-body">

                  <div class="col-md-12">

                    <a href="<?php echo e(route('add_sub_category')); ?>" class="btn btn-outline-secondary btn-fw text-right"><i class="fa fa-plus"></i></a>

                  </div>

                  <div class="table-responsive">



                    <table class="table table-striped">

                      <thead>

                        <tr>

                          <th>Name</th>

                          <th>Banner</th>

                          <th>Attributes</th>

                          <th>Date of created</th>

                          <th>Action</th>

                        </tr>

                      </thead>

                      <tbody>

                        <?php if(!$sub_category->isEmpty()): ?> <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr id="<?php echo e($key->id); ?>">

                          <td>

                            &emsp;<?php echo e($key->title); ?></td>

                            <td><?php if($key->banner){?><img src="<?php echo e(url('public/'.$key->banner)); ?>" alt="image" style="width: 100px;border-radius: unset;" />

                          <?php }?></td>

                          <td><a href="<?php echo e(route('attribute',['sub_category',$key->id])); ?>" class="btn btn-outline-primary btn-sm">Attribute</a></td>

                          <td><?php echo e(date('Y F, d',strtotime($key->created_at))); ?></td>

                          <td>

                            <div>

                              <a href="<?php echo e(route('edit_sub_category',[$key->id])); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>

                              <a href="javascript:;" class="btn btn-danger btn-sm" onclick="delete_row('<?php echo e($key->id); ?>','sub_categories')"><i class="fa fa-trash"></i></a>

                            </div>

                          </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                      </tbody>

                    </table>
<?php echo $sub_category->links(); ?>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>

       

      </div>

	   <script>

	  $( "body" ).addClass('sidebar-icon-only');

	  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bazarhat99/public_html/resources/views/admin/subcategory/list.blade.php ENDPATH**/ ?>